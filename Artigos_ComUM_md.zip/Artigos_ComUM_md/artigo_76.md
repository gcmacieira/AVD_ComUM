---
date: 05Jul2023
author: Marta Rodrigues
image: https://www.comumonline.com/wp-content/uploads/2022/10/Jose-Costa_Universidade-do-Minho_05-1500x1000.jpg
title: Eleições Senado Académico. Eleitos cinco membros da Lista A e um da Lista B
url: https://www.comumonline.com/2023/07/eleicoes-senado-academico-lista-a-elege-cinco-representantes-e-lista-b-elege-um/
site: ComUM
description: A Lista A obteve a maioria dos votos nas eleições para representante dos estudantes no Senado Académico, totalizando 683 deles (75,72%).
tags: Universidade do Minho, Senado Académico, Eleições Senado Académico 2023, Lista B - Por todos os estudantes, Lista A - Mais Academia
type: article
---


# Eleições Senado Académico. Eleitos cinco membros da Lista A e um da Lista B

## Registaram-se 902 votos, num universo de 20 950 eleitores.

05Jul2023 | Marta Rodrigues

A Lista A obteve a maioria dos votos nas eleições para representante dos estudantes no Senado Académico, totalizando 683 deles (75,72%). Já a Lista B alcançou 184 votos (20,40%). Dada a aplicação do método d’Hondt, a lista A elege cinco representantes e a lista B elege um, depois da eleição que decorreu esta quarta-feira através da plataforma e-VotUM.

Contabilizam-se ainda 35 votos em branco. Num total de 20 950 eleitores, apenas 902 exerceram o direito ao voto, o que corresponde a uma taxa de abstenção a rondar os 95%. Da lista maioritária, constam a cabeça de lista Sónia Fernandes e os elementos Maria Machado, Tiago Nogueira, Pedro Antunes e Tito Correia. Da lista B, apenas o cabeça de lista, Rúben Monteiro, vai ser representante.

Relembre-se que nas últimas eleições, em 2021, a abstenção foi dois pontos percentuais mais baixa e o universo de votantes chegou aos 1251 estudantes. Contudo, concorriam três listas.

