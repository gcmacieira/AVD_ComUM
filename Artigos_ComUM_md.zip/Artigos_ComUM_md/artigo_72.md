---
date: 07Dez2021
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2021/12/DSC_0687-1500x1000.jpg
title: Eleições AAUM. Abstenção mantém-se na ordem dos 80%
url: https://www.comumonline.com/2021/12/eleicoes-aaum-abstencao-mantem-se-na-ordem-dos-80/
site: ComUM
description: Nestas eleições para os órgãos sociais da Associação Académica da Universidade do Minho (AAUM) votaram 3.896 alunos. A abstenção caiu para os 78,17%.
tags: AAUM, abstenção, eleições, e-VotUM, 2021
type: article
---


# Eleições AAUM. Abstenção mantém-se na ordem dos 80%

## 

07Dez2021 | ComUM Online

Nestas eleições para os órgãos sociais da Associação Académica da Universidade do Minho (AAUM) votaram 3.896 alunos. Este ano, a abstenção cai para os 78,17%. No ano passado, a taxa diminuiu para os 78,2%, registando-se a maior queda dos últimos quatro anos. Em 2019, registou-se uma abstenção de 84%.

Os cadernos eleitorais contaram com 17.845 eleitores, mais 811 alunos, em comparação com o ano passado. Tal como nas eleições de 2020, a votação realizou-se via e-VotUM.



Segundo Duarte Lopes, novo presidente da Associação Académica da Universidade do Minho (AAUM), "a abstenção continua a ser vitoriosa". "Devemos começar a pensar como podemos analisar estes resultados. Deve haver espaço de reflexão sobre este valor e deve haver, sobretudo, espaço para pensar como podemos corrigir isto", nota. O estudante considera que a adoção do e-VotUM "foi o primeiro para passo para combater a abstenção". No entanto, "cabe à direção pensar sobre outros mecanismos que poderão ajudar reduzir estes valores", acrescenta.

De acordo com Rui Oliveira, atual presidente da AAUM, "a abstenção tende a ser a grande vencedora de qualquer noite eleitoral do país". "Infelizmente, continuamos a não dar a atenção que deveríamos aos processos eleitorais", declara. O estudante reforça que há uma elevada taxa de abstenção devido à falta de informação que os alunos têm relativamente às eleições. "Eu responsabilizo-me e à direção, que tem de ser naturalmente mais eficaz na forma como comunica".

"O que aconteceu este ano acaba por ser semelhante com o que aconteceu nos anos anteriores", explica Rafael Couto, presidente da Comissão Eleitoral. "O que falta é mais informação por parte dos alunos", admite.

Nuno Carvalho, membro Comissão Eleitoral, demitiu-se um dia antes das eleições e acusou o órgão de "má conduta". Para Rafael Couto, esta situação "não descredibiliza o trabalho que a Comissão Eleitoral realizou". "Acho que dentro da Comissão Eleitoral não existem divergências tão fortes para se apresentar demissão", mas "o Nuno, não concordando com algumas opiniões, decidiu fazê-lo e está no seu direito", conclui.

Entrevistas: Maria Carvalho, Maria Francisca Barros e Nuno Pereira

Multimédia: Joana Dantas e Joana Oliveira

