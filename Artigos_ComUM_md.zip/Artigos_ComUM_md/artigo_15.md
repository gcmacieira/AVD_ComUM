---
date: 30Out2022
author: Inês Machado
image: https://www.comumonline.com/wp-content/uploads/2018/12/Stock-18-1500x1000.jpg
title: AAUMinho nega apoio a protesto de estudantes no Prometeu
url: https://www.comumonline.com/2022/10/aauminho-nega-apoio-a-protesto-de-estudantes-no-prometeu/
site: ComUM
description: A concentração do movimento “Onde está a ação social?”, elaborado pelos estudantes da Universidade do Minho, está marcado para quarta-feira, pelas 17h.
tags: UMinho, Duarte Lopes, Associação Académica da Universidade do Minho (AAUM), Luís Esteves
type: article
---


# AAUMinho nega apoio a protesto de estudantes no Prometeu

## O assunto foi debatido na Reunião Geral de Alunos

30Out2022 | Inês Machado

A concentração do movimento “Onde está a ação social?”, elaborado pelos estudantes da Universidade do Minho, está marcado para quarta-feira, pelas 17h, no Prometeu, junto ao complexo pedagógico dois, no Campus de Gualtar. A moção apresentada foi rejeitada, com 53 votos contra, 17 a favor e 12 abstenções.

O porta-voz do movimento independente, Luís Esteves, declarou através do manifesto que os alunos “continuam a sofrer com a falta de camas”, exigindo “mais alojamento publico” para fazer frente aos “preços incomportáveis e especulativos dos quartos e residências privadas”. O representante sublinhou também o quadro onde apenas 30% dos estudantes da academia são bolseiros e essa bolsa “não cobre a maioria das despesas”, como alimentação, transporte, alojamento e materiais de estudo.

Além disso, Luís Esteves considera que a oferta da refeição social é “insuficiente”, isto porque as filas são “enormes e por períodos prolongados” impedindo os alunos de almoçarem uma “refeição variada, equilibra e completa a um preço acessível”. Para Luís este problema leva os estudantes a optarem por “refeições rápidas, de baixo custo e valor nutricional”.

O representante do movimento mostrou-se desiludido com a falta de apoio relativamente ao problema no “deslocamento dos estudantes do campus de Azurém para o de Gualtar”. Luís Esteves classifica o ato como “um passo atrás naquilo que é o papel que a UMinho deveria cumprir, dar forças à voz dos estudantes”.

Esta moção foi considerada pelo presidente da Associação Académica da Universidade do Minho (AAUMinho), Duarte Lopes, como “não oportuna” no momento, já que os dirigentes estudantis “têm sido ouvidos”. No seu entender, têm sido conseguidos avanços como o alargamento das condições de elegibilidade para a bolsa de estudo, assim como o aumento dos valores das bolsas atribuídas aos alunos de mestrado. “Saber que está prometido, para breve, uma bolsa de estudo que pague a totalidade do mestrado dos estudantes deixa-nos muito satisfeitos”, sublinhou o responsável máximo pela associação académica.

