---
date: 29Ago2023
author: Margarida da Silva Carvalho
image: https://www.comumonline.com/wp-content/uploads/2017/11/IMG_6239-T45-1500x1000.jpg
title: Rui Castro coloca UMinho num “patamar muito elevado”
url: https://www.comumonline.com/2023/08/rui-castro-coloca-uminho-num-patamar-muito-elevado/
site: ComUM
description: O Reitor da Universidade do Minho, Rui Vieira de Castro, acredita que a instituição se encontra num "patamar muito elevado", dada a grande taxa de ocupação.
tags: Universidade do Minho, Concurso Nacional de Acesso ao Ensino Superior, Reitor Rui Vieira de Castro
type: article
---


# Rui Castro coloca UMinho num “patamar muito elevado”

## Os colocados rondam os 97%, reservando 85 vagas para a 2º fase.

29Ago2023 | Margarida da Silva Carvalho

As colocações da primeira fase de acesso ao ensino superior colocam a Universidade do Minho como uma das universidades do país com maior taxa de ocupação. O preenchimento elevado foi realçado pelo Reitor da academia minhota. Rui Castro refere, em declarações à RUM, que “alargámos o número de vagas e mantivemos uma taxa de preenchimento num patamar muito elevado”.

A UMinho abriu 3.013 vagas, mais 25 do que no ano passado, estando distribuídas pelo concurso nacional e local, no caso da licenciatura de música. O Reitor acredita que, face ao cenário dos anos anteriores, as 85 vagas disponíveis vão ser preenchidas na 2º e 3º fases.

A Licenciatura em Engenharia Aeroespacial, que caminha para o seu segundo ano de existência, foi a que apresentou a maior média do último colocado no país. Rui Castro sublinha que o curso “vem dar resposta à nossa convicção de que a universidade deve procurar estar atenta àquilo que são as novas áreas que vão emergindo”.

O Reitor destacou ainda que a UMinho tem 10 licenciaturas com o valor mais elevado no país e que 22 dos 56 cursos registaram uma nota mínima de ingresso de 16. Segundo o responsável pela instituição, esses dados refletem “a quantidade e a qualidade da procura da qual a academia minhota tem sido objeto”.

