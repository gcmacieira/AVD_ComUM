---
date: 08Nov2021
author: Maria de Pinto Freitas
image: https://www.comumonline.com/wp-content/uploads/2021/11/Rececao-ao-Caloiro-2021-1500x1000.jpg
title: Receção ao Caloiro 2021: uma despedida em grande
url: https://www.comumonline.com/2021/11/rececao-ao-caloiro-2021-uma-despedida-em-grande/
site: ComUM
description: O Multiusos de Guimarães acolheu os dois últimos dias de receção. Por mais um ano, a academia minhota despediu-se do evento dedicado aos caloiros.
tags: UMinho, Multiusos de Guimarães, toy, Receção ao Caloiro 2021, Lon3r Johnny, Julinho KSD
type: article
---


# Receção ao Caloiro 2021: uma despedida em grande

## Guimarães recebeu Toy, Lon3r Johny e Julinho KSD nos últimos dois dias do evento.

08Nov2021 | Maria de Pinto Freitas

O Multiusos de Guimarães acolheu os dois últimos dias de Receção ao Caloiro com muita música e dança à mistura. Por mais um ano, a academia minhota despediu-se do evento dedicado aos novos alunos.

Diogo Fragata, vencedor da iniciativa DJ@UM, abriu a pista na penúltima noite de receção. Seguiu-se a atuação de Toy, que encheu o público de gargalhadas e emoção. Segundo o artista, “é um prazer participar em eventos destas dimensões”, já que pode “extravasar” o seu lado mais “louco”. A loucura foi contagiada para a plateia que, em uníssono, cantou músicas como “Chama o António”, “És tão sensual”, “Estupidamente apaixonado” e “Rosa negra”.

Favela Lacroix foi a terceira artista da noite. A artista e ícone da comunidade LGBTQ+ demonstrou versatilidade nos géneros musicais que apresentou. Na mesma atuação, Favela propagou as suas coreografias frenéticas pelo público, mas também encantou e embalou com a balada “A tua voz”.

Os Meninos do Rio concluíram a noite do dia 5 de novembro com as suas misturas e energia. A multidão juntou-se na frente do palco para saltar ao som dos clássicos e das novas tendências musicais. O trio de DJs declarou que “a sensação de voltar é muito boa”. A atuação foi “especial” para os artistas, que afirmaram estar “em casa”.

Na última noite, o recinto do Multiusos atingiu a sua lotação máxima. Desta vez foi o DJ G-Soul quem fez as honras de iniciar as atuações de sábado. De seguida, Lon3r Johny entrou em palco com uma animação contagiante que pôs o público ao rubro. Com recinto cheio, “SKRT”, “SUCESSO” e “DAMN/SKY” criaram uma onda de saltos e gritos.

Seguiu-se Julinho KSD com um espetáculo repleto de ritmo. “Stunka”,  “Sentimento Safari” e “Hoji N’ka ta Rola” foram alguns dos temas cantados pelo artista. Segundo o músico, “as expectativas foram ultrapassadas”.

A última noite da Receção ao Caloiro 2021 terminou com o DJ Marinho. O artista proporcionou um espetáculo de grande diversão com os hits internacionais. Por fim, concluiu com emoção e nostalgia  que a música portuguesa traz consigo.

 

