---
date: 01Nov2023
author: Luana Pereira
image: https://www.comumonline.com/wp-content/uploads/2023/08/Braga-residenciaAndy.png
title: Parceria com a residência privada Andy Student Living vai trazer descontos aos sócios da AAUMinho
url: https://www.comumonline.com/2023/11/parceria-com-a-residencia-privada-andy-student-living-trara-beneficios-aos-socios-da-aauminho/
site: ComUM
description: A residência privada Andy Student Living, inaugurada em setembro deste ano, alinhou numa colaboração com a Associação Académica da Universidade do Minho.
tags: AAUMinho, Andy Student Living
type: article
---


# Parceria com a residência privada Andy Student Living vai trazer descontos aos sócios da AAUMinho

## Não há data prevista para os benefícios entrarem em vigor.

01Nov2023 | Luana Pereira

A residência privada Andy Student Living, inaugurada em setembro deste ano, vai fazer descontos aos sócios da Associação Académica da Universidade do Minho (AAUMinho). Margarida Isaías, presidente da AAUMinho, adiantou a informação na Reunião Geral de Alunos, que decorreu esta segunda-feira, no Campus de Azurém da Universidade do Minho.

A presidente esclarece que esta pareceria consta na dinamização da divulgação da nova residência, a troco de descontos na mesma, para sócios da AAUMinho, e da conceção de uma verba no valor de 6 mil euros, atribuída este ano à associação. A percentagem de descontos aplicada aos estudantes ainda vai ser analisada.

Margarida Isaías, reconhece a carência de parcerias com várias entidades, não só pela “necessidade de receita”, mas também para benefício dos estudantes. “Procuramos que essas parcerias sejam vantajosas, não só para a Associação Académica, mas também para todos os estudantes, e em especial para aqueles que são sócios”.

