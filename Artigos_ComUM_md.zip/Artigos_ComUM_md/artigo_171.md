---
date: 23Mar2018
author: Ana Maria Ramos
image: https://www.comumonline.com/wp-content/uploads/2017/10/IMG_3277-T55-e1632422468321-1500x663.jpg
title: UM vai desligar luzes na Hora do Planeta
url: https://www.comumonline.com/2018/03/um-vai-desligar-luzes-na-hora-do-planeta/
site: ComUM
description: 
tags: UMinho, Hora do Planeta
type: article
---


# UM vai desligar luzes na Hora do Planeta

## A Universidade do Minho volta a aderir à Hora do Planeta.

23Mar2018 | Ana Maria Ramos

O planeta Terra vai apagar as luzes durante uma hora este sábado. Ás 20h30, a Universidade do Minho junta-se ao movimento promovido pelo World Wide Fund For Nature (WWF) ao desligar a iluminação exterior de alguns dos seus edifícios.

Ficarão às escuras o Largo do Paço, a sede dos Serviços de Ação Social da Universidade do Minho e a cantina do campus de Gualtar, em Braga. Na cidade-berço, também a iluminação exterior do complexo desportivo e das residências do campus de Azurém será desligada. O momento será assinalado com uma atuação do Grupo de Poesia da UMinho no Largo do Paço.

A iniciativa é uma parceria entre a Associação Académica e os SASUM e visa reforçar a consciência ambiental e a política de sustentabilidade da Academia, afirmada no Plano Estratégico da UMinho 2020.

Pelo mundo serão desligadas as iluminações de vários monumentos, como símbolos de esperança. O movimento nasceu em Sidney, Austrália, em 2007, como uma tomada de posição contra as alterações climáticas e tornou-se um fenómeno global.

