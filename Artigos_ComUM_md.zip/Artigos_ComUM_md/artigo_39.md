---
date: 29Nov2021
author: Maria Carvalho
image: https://www.comumonline.com/wp-content/uploads/2019/10/MariaCarvalho_ILCH_003-1500x898.jpg
title: Assédio na UMinho. Reitor garante “procedimentos de averiguação”
url: https://www.comumonline.com/2021/11/assedio-na-uminho-reitor-garante-procedimentos-de-averiguacao/
site: ComUM
description: O reitor revelou que vão ser iniciados procedimentos para averiguar as situações de assédio sexual e os atos de exibicionismo de índole sexual.
tags: reitor, UMinho, Gualtar, Assédio, autoridades, atos de exibicionismo
type: article
---


# Assédio na UMinho. Reitor garante “procedimentos de averiguação”

## O responsável máximo da academia apela a que todos os episódios sejam reportados.

29Nov2021 | Maria Carvalho

Durante a cerimónia investidura de Rui Vieira de Castro, o reitor revelou à RUM que vão ser iniciados procedimentos para averiguar as situações de assédio sexual na residência Lloyd e os “atos de exibicionismo de índole sexual” no campus de Gualtar. A reitoria comunicou ainda, esta segunda-feira, que o trabalhador acusado de assédio foi retirado do seu posto de trabalho.

Rui Vieira de Castro notou que a universidade vai melhorar a iluminação no campus e que vão ser tomadas medidas em relação à vegetação. Para além disso, o responsável garantiu que o setor de segurança da instituição vai proceder a uma maior monitorização do espaço.

O reitor declarou que já conversou com os responsáveis pelo setor e que “vão ser desencadeados procedimentos de averiguação e vai haver decisões a serem tomadas”. Essas informações vão ser reveladas em breve, confirmou.

Em comunicado, a universidade afirma lamentar “profundamente” os “atos exibicionistas e de assédio a estudantes desta instituição, praticados por individuo(s) não identificado(s). Em relação à acusação de assédio, a reitoria nota que “já desencadeado um processo de inquérito, tendo sido determinada a retirada do trabalhador em causa do seu posto de trabalho”.

A Universidade do Minho (UMinho) lançou, na passada sexta-feira, um comunicado onde confirma “atos de exibicionismo de índole sexual”, junto ao Complexo Pedagógico 1 do Campus de Gualtar. De acordo com o reitor, já foi reforçada a segurança pelas autoridades de modo a identificar a pessoa ou pessoas responsáveis por estes atos.

