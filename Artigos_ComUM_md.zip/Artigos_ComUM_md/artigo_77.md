---
date: 28Jul2021
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2019/03/IMG_9021-1500x1000.jpg
title: Eleições Senado Académico: Lista B vence e elege quatro representantes
url: https://www.comumonline.com/2021/07/eleicoes-senado-academico-lista-b-vence-e-elege-quatro-representantes/
site: ComUM
description: Num universo de 1251 estudantes votantes, a lista B obtém 641 votos. A lista A fica em segundo lugar, com 417 votos. A lista C não consegue nenhum lugar.
tags: Universidade do Minho, Senado Académico, e-VotUM, Rodrigo Dinis, Eleições para os representantes dos alunos, Lista A - Agir pela Academia, Lista B - A Voz da Academia, Lista C - Dos alunos para os alunos, Joana Fraga
type: article
---


# Eleições Senado Académico: Lista B vence e elege quatro representantes

## Num universo de 1251 estudantes votantes, a lista B obtém 641 votos. A lista A fica em segundo lugar, com 417 votos.

28Jul2021 | ComUM Online

A cabeça da lista B, Joana Fraga, conquistou o maior número de votos na eleição dos representantes dos estudantes no Senado Académico, que decorreu esta quarta-feira através do e-votUM. Ao lado dos quatro eleitos desta lista, vão estar também dois candidatos da Lista A, presidida por Rodrigo Dinis.

Desta forma, a Lista C, encabeçada por Jéssica Valente, não elegeu nenhum representante no ato eleitoral. Contou apenas com 145 votos. Em relação aos votos em branco, contabilizam-se 48. A taxa de abstenção ronda os 93%.



Para Rodrigo Dinis, “o resultado está dentro das expectativas”. A lista A “conseguiu cumprir a primeira coisa a que se comprometeu – chamar atenção para este órgão tão importante da universidade”. Da mesma forma, Joana Fraga considera que “o resultado era mais ou menos o esperado”.

“Há muitos alunos em estágio ou a trabalhar, por isso já se sabia que ia haver uma taxa de abstenção muito elevada”, admite a eleita. Por outro lado, Rodrigo acredita que “foi muito importante o aumento da participação dos estudantes, o que mostra que se conseguiu mobilizar as pessoas”.

Além dos dois representantes da lista A, há os quatro representantes da lista B, por isso, para Rodrigo Dinis o objetivo é “tentar cooperar, sem vergar”. “Temos as nossas propostas, ideias e ambições e queremos realmente fazê-las ouvir neste órgão, queremos causar impacto”, acrescenta o eleito. Segundo Joana Fraga, a prioridade vai ser a ação social, a atualização das residências universitárias e a questão da saúde mental. A estudante defende que “é preciso prevenir [eventuais patologias mentais] antes de se tornar um problema grave, criando uma rede de apoio e de prevenção”.

Por último, Rodrigo afirma que “os votos podiam ter sido mais, mas o que interessa é que vamos conseguir defender os direitos dos estudantes, sendo este o nosso propósito”. Por sua vez, Joana considera que “o alcance que o órgão do senado académico tem faz com que os alunos consigam chegar mais longe, com mais conhecimento e com mais poder”.

Assim, o Senado Académico será constituído pelos seguintes representantes dos estudantes: Joana Carolina Santos Fraga (lista B), Ana Luísa Santos Silva (lista B), Catarina Araújo Machado (lista B), Francisco Maria Rocha Santos Madureira (lista B), Rodrigo Miguel Vieira da Fonseca Dinis (lista A) e Ana Catarina Dias Lopes (lista A).

Na última eleição, em 2019, apenas houve uma lista candidata. O universo eleitoral não passou dos 200 votantes.

Artigo escrito por: Joana Oliveira e Maria Francisca Barros

