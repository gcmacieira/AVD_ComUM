---
date: 06Dez2023
author: Ana Beatriz Ferreira
image: https://www.comumonline.com/wp-content/uploads/2023/12/IMG_8446-1500x1000.jpg
title: Eleições AAUMinho. Abstenção sobe para 87%
url: https://www.comumonline.com/2023/12/eleicoes-aauminho-abstencao-sobe-para-87/
site: ComUM
description: A taxa de abstenção para as eleições da AAUMinho em 2023 atingiu os 87,5%. Este valor foi algo lamentável por todos os candidatos.
tags: UMinho, Associação Académica da Universidade do Minho, Taxa de abstenção, Eleições AAUMinho 2023
type: article
---


# Eleições AAUMinho. Abstenção sobe para 87%

## Abstenção sobe cerca de três pontos percentuais em relação a 2022.

06Dez2023 | Ana Beatriz Ferreira

Nestas eleições para os órgãos de governo da Associação Académica da Universidade do Minho (AAUMinho) votaram 5400 estudantes, o que representa uma percentagem de 87,48% votos. Este ano, a abstenção subiu de 84% para 87%, registando-se a maior subida dos últimos anos. Em 2019, a abstenção fixou-se nos 84,11%.



Os cadernos eleitorais contaram com 19.958 eleitores, mais 1385 estudantes, em comparação com 2022. À semelhança dos anos anteriores, as votações realizaram-se online, via e-VotUM.

Margarida Isaías, atual presidente da AAUMinho, explicou que para este mandato pretende melhorar a participação dos estudantes na política académica, de forma a prevenir uma subida ainda maior destes valores.

