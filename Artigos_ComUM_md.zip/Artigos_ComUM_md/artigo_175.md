---
date: 25Set2022
author: Marta Ferreira
image: https://www.comumonline.com/wp-content/uploads/2017/09/esta-1500x844.jpg
title: UMinho avança com a abertura de um polo em Esposende
url: https://www.comumonline.com/2022/09/uminho-avanca-com-a-abertura-de-um-polo-em-esposende/
site: ComUM
description: O reitor da Universidade do Minho, Rui Vieira de Castro, anunciou que a abertura de um novo polo no município de Esposende está pensado para breve.
tags: Universidade do Minho, reitor, UMinho, Arcos de Valdevez, Rui Vieira de Castro, Esposende, Reitor Rui Vieira de Castro
type: article
---


# UMinho avança com a abertura de um polo em Esposende

## Reitor afirma que o “trabalho está muito adiantado”.

25Set2022 | Marta Ferreira

O reitor da Universidade do Minho, Rui Vieira de Castro, anunciou que a construção de um novo polo no município de Esposende está pensado para breve. A informação foi adiantada na receção aos novos alunos da academia minhota, onde foi também revelada a possibilidade de abertura de um novo espaço em Arcos de Valdevez.

O projeto pensado para Esposende destina-se à instalação do Instituto Multidisciplinar de Ciência e Tecnologia Marinha, localizado na instalação Radionaval da Apúlia. Em declarações prestadas à RUM, Rui Vieira de Castro confessou que “o trabalho está muito adiantado”, uma vez que “os projetos de arquitetura estão assumidos e há concursos lançados”.

Para além de Esposende, o representante máximo da academia minhota referiu ainda que há um novo projeto em estudo para o concelho de Arcos de Valdevez. “Estão já identificados os espaços potenciais para a localização desse novo polo”, declarou o responsável sobre a abertura do novo polo.

