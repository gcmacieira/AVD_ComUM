---
date: 19Dez2022
author: Maria Francisca Barros
image: https://www.comumonline.com/wp-content/uploads/2022/12/314063178_9027201020639107_8210286556445903616_n-1.jpg
title: Tomada de posse da nova direção da AAUMinho é dia 7 de janeiro
url: https://www.comumonline.com/2022/12/tomada-de-posse-da-nova-direcao-da-aauminho-e-dia-7-de-janeiro/
site: ComUM
description: Margarida Isaías vai tomar posse como presidente da Associação Académica da Universidade do Minho (AAUMinho) no próximo ano, a 7 de janeiro.
tags: Conselho Fiscal e Jurisdicional, 2022/2023, Direção, Mesa da Reunião Geral de Alunos, Margarida Isaías, Pedro Antunes, Miguel Lima, Tomada de Posse AAUMinho
type: article
---


# Tomada de posse da nova direção da AAUMinho é dia 7 de janeiro

## Margarida Isaías vai ser a segunda mulher a presidir a direção da AAUMinho em 45 anos de história.

19Dez2022 | Maria Francisca Barros

Margarida Isaías vai tomar posse como presidente da Associação Académica da Universidade do Minho (AAUMinho) no próximo ano, a 7 de janeiro. Vão ser empossados também os representantes eleitos para a Mesa da Reunião Geral de Alunos, Miguel Lima, e para o Conselho Fiscal e Jurisdicional (CFJ), Pedro Antunes.

A sessão solene vai decorrer no Salão Medieval da Reitoria, no Largo do Paço.

Recorde-se que as eleições decorreram no passado dia 6 de dezembro onde a lista da aluna de Medicina ganhou com 82.51% dos votos. Miguel Lima venceu com 60.42% dos votos e Pedro Antunes com 59.36%.

