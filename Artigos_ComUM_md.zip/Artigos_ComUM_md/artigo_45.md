---
date: 24Nov2023
author: Luana Pereira
image: https://www.comumonline.com/wp-content/uploads/2019/03/IMG_9021-1500x1000.jpg
title: Aumento do apoio à deslocação para estudantes bolseiros é aprovado
url: https://www.comumonline.com/2023/11/aumento-do-apoio-a-deslocacao-para-estudantes-bolseiros-e-aprovado/
site: ComUM
description: A proposta do Partido Socialista (PS), de aumento do apoio à deslocação de estudantes bolseiros, foi ontem aprovada no Orçamento de Estado.
tags: ensino superior, bolseiros, Partido Socialista, Deslocação
type: article
---


# Aumento do apoio à deslocação para estudantes bolseiros é aprovado

## O Partido Socialista conta com duas propostas aprovadas no Orçamento de Estado de 2024 e consegue apoio de 40 euros mensais para estudantes bolseiros deslocados.

24Nov2023 | Luana Pereira

A proposta do Partido Socialista (PS), de aumento do apoio à deslocação de estudantes bolseiros, foi ontem aprovada no Orçamento de Estado. A benesse consiste num acréscimo de 15 euros, passando agora os bolseiros a receber uma quantia de 40 euros mensais. Este novo valor retrata um aumento de 60% face ao apoio já existente. O apoio máximo anual para estes estudantes sobe, assim, de 250 para 400 euros.

O PS apresentou uma proposta que visa a regularização do património imobiliário das instituições de ensino superior até 31 de dezembro de 2024, bem como um auxílio financeiro do Governo à verba estipulada a cada instituição de ensino superior pública. Deste modo, pretende-se um apoio de 40 euros por mês, mais um euro por refeição para os estudantes bolseiros.

Foi também aprovada uma outra proposta socialista que abrange a digitalização do ensino português no estrangeiro. Espera-se que “a utilização de ferramentas, tecnologias e aulas à distância para tornar o ensino mais atrativo, dinâmico, interativo e ajustado ao perfil dos estudantes, adaptando para o efeito o respetivo regime jurídico às necessidades contemporâneas” seja possível em 2024.

