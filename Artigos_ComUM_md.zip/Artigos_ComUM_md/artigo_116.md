---
date: 
author: 
image: 
title: Mais de 2500 alunos admitidos na UM
url: https://www.comumonline.com/2013/10/mais-de-2500-alunos-admitidos-na-um/
site: ComUM
description: 
tags: Universidade do Minho
type: article
---


# Mais de 2500 alunos admitidos na UM

## 

 | 

Este ano a Universidade do Minho (UM) recebeu 2.593 novos alunos. Este é o total de estudantes que entrou na primeira e segunda fases do concurso nacional de acesso ao ensino superior, de acordo com os números fornecidos pelo Gabinete de Comunicação, Informação e Imagem da UM.

Medicina e Engenharia Biomédica foram os cursos com as médias de entrada mais elevadas. De acordo com os dados disponibilizados pela Direção-Geral do Ensino Superior (DGES), a nota do último colocado em Medicina foi de 18,2 valores, enquanto que em Engenharia Biomédica correspondeu a 17,2 valores.

No entanto, nem todos os cursos conseguiram preencher todas as vagas. É o caso de alguns dos cursos de engenharia, tais como Engenharia Biológica, Civil, de Comunicações, de Materiais, Têxtil e de Polímeros. Também as licenciaturas de Estudos Portugueses e Lusófonos, Estudos Culturais, Filosofia, Física, Geologia, Química, Optometria e Negócios Internacionais ficaram com vagas por ocupar, segundos os dados apresentados no site da DGES.

Quanto às expetativas profissionais, Marta Roda, aluna 1º ano do curso de Ciências da Comunicação, mostra-se cautelosa: “Escolhi este curso por ser aquilo que gostaria de fazer na minha vida, mas claro que receio o número de oportunidades que poderei ter para um futuro minimamente sustentável”.

A estudante apontou ainda a atual conjuntura económica como uma dificuldade que se impõe aos estudantes do ensino superior. “A crise afetou a maioria dos cursos e futuros empregos, bem como os respetivos mercados de trabalho, destacando-se apenas aqueles [alunos] que se esforçam e têm um percurso académico favorável”, comentou.

Inês Leal
Miguel Faria

