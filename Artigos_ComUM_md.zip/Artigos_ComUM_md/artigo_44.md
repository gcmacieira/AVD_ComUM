---
date: 12Out2016
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2016/10/IMG_7684-1500x1000.jpg
title: Aumento das senhas. “Tenho a certeza que este aumento vai ser revertido”, garante presidente da AAUM
url: https://www.comumonline.com/2016/10/aumento-das-senhas-tenho-a-certeza-que-este-aumento-vai-ser-revertido-garante-presidente-da-aaum/
site: ComUM
description: 
tags: Universidade do Minho, AAUM, Bruno Alcaide, senhas
type: article
---


# Aumento das senhas. “Tenho a certeza que este aumento vai ser revertido”, garante presidente da AAUM

## 

12Out2016 | ComUM Online

Os alunos da Universidade do Minho estão contra o aumento de 15 cêntimos no preço das senhas de refeição. Numa reunião ontem organizada por alunos da universidade, na qual a Associação Académica (AAUM) também participou, discutiram-se formas de manifesto contra este aumento. A AAUM prometeu lutar para “reverter” esta situação.

Desde o dia 1 de Outubro que uma senha de refeição individual na UMinho custa 2,65€. Esta actualização deveu-se ao aumento do salário mínimo nacional (SMN) para 530€, uma vez que o valor da senha está indexado ao SMN. Uma das promotoras desta reunião, Ana Ramôa, diz que a indexação ao SMN não deveria ser uma “desculpa” para se aumentar as senhas e lembrou que algumas universidades aumentaram apenas parte do valor, suportando o restante.

Bruno Alcaide, presidente da AAUM, foi duro nas críticas aos Serviços de Acção Social (SASUM) e à reitoria. “Os SASUM há muito tempo que são insuficientes. Se não fossem não teria sido criado o fundo social de emergência”, disse na reunião. O dirigente lembrou que Carlos Silva, administrador dos serviços sociais, tem “muito poder nestas matérias”. Além disso, sublinhou “a missão de financiamento cabe ao Estado, não às universidades ou aos alunos”.

Isac Valente, presidente da Associação de Alunos de Arqueologia e um dos organizadores destas reuniões (que decorreram em Gualtar e Azurém), diz que “a cantina social não é um restaurante” e que “a pressão” contra os preços das senhas “deve ser feita pela massa estudantil”.

Durante a reunião, não foram esquecidos assuntos como a passagem da Universidade do Minho ao regime de fundação e a devolução da taxa de 300€ cobrada a alunos de doutoramento pela apresentação da tese.

RGA convocada para daqui a duas semanas

Nas declarações que prestou ao ComUM no mês passado, Bruno Alcaide referiu que “por muito que queiramos fazer alguma coisa, não conseguimos”. Agora, admitiu ter-se “exprimido mal” e que não pretendia dar a ideia de que a AAUM “não estava preocupada com este aumento”.

Pelo contrário, ao longo da reunião, referiu diversas vezes que os alunos “podem contar com a palavra da Associação”. “Tenho a certeza que, a muito breve prazo, esta situação será revertida”, garantiu. Bruno Alcaide adiantou ainda que será convocada para daqui a duas semanas uma Reunião Geral de Alunos para discutir este assunto.

Texto: Catarina Pinheiro e Eduardo Miranda

