---
date: 30Ago2023
author: Mariana Lopes
image: https://www.comumonline.com/wp-content/uploads/2023/08/45109.jpg
title: AAUMinho vai alargar espaço exterior da Receção ao Caloiro
url: https://www.comumonline.com/2023/08/aauminho-vai-alargar-espaco-exterior-da-rececao-ao-caloiro/
site: ComUM
description: A Associação Académica da Universidade do Minho (AAUMinho) vai alargar o espaço exterior da Receção ao Caloiro que irá decorrer de 27 a 30 de setembro.
tags: Receção ao Caloiro, Multiusos de Guimarães, Acolhimento, AAUMinho, Margarida Isaías
type: article
---


# AAUMinho vai alargar espaço exterior da Receção ao Caloiro

## Multiusos de Guimarães recebe de 27 a 30 de setembro o evento que dá as boas-vindas aos novos alunos.

30Ago2023 | Mariana Lopes

A Associação Académica da Universidade do Minho (AAUMinho) vai alargar o espaço exterior da Receção ao Caloiro. O evento irá decorrer de 27 a 30 de setembro, no Multiusos de Guimarães. A novidade foi dada pela presidente da estrutura, Margarida Isaías, à RUM.

Em 2022, na Receção ao Caloiro, foi criada pela AAUMinho um espaço exterior. Segundo a responsável pela associação, este ano pretende-se “alargá-lo, para ter mais serviços de alimentação e divertimento”. Acrescentou ainda que “o cartaz será divulgado em breve, sendo previsível que, na primeira semana de aulas, já sejam conhecidos todos os nomes e os bilhetes estejam à venda”.

A sessão de boas-vindas no campo de Azurém decorrerá a 7 de setembro e, em vez do habitual almoço do reitor, haverá um piquenique alusivo aos 50 anos da Universidade do Minho. O programa do acolhimento aos novos alunos conta ainda com o GPS pelos campi e pelas cidades, a Latada, no dia 27 de setembro, e as Serenatas Velhas, no dia anterior. Antes disso, no dia 20, as piscinas da Rodovia, em Braga, recebem mais uma edição do Caloiro de Molho.

