---
date: 12Out2020
author: João Pedro Sousa
image: https://www.comumonline.com/wp-content/uploads/2020/10/0J9A6476-1500x1000.jpg
title: Conselho Geral da UMinho discute funcionamento do novo ano letivo
url: https://www.comumonline.com/2020/10/conselho-geral-da-uminho-discute-funcionamento-do-novo-ano-letivo/
site: ComUM
description: O Conselho Geral da Universidade do Minho está a realizar esta segunda-feira, 12 de outubro, uma reunião ordinária, aberta ao público.
tags: Universidade do Minho, UMinho, sociedade, Conselho Geral, Regional
type: article
---


# Conselho Geral da UMinho discute funcionamento do novo ano letivo

## A reunião ordinária decorre ao longo desta segunda-feira no salão nobre da Reitoria da academia minhota.

12Out2020 | João Pedro Sousa

O Conselho Geral da Universidade do Minho está a realizar esta segunda-feira, 12 de outubro, uma reunião ordinária, aberta ao público. O objetivo da sessão é organizar o funcionamento deste novo ano letivo.

Na agenda, são de destaque assuntos de iniciativa do Reitor, como é o caso do Código de Conduta Ética e a avaliação da aplicação do regime fundacional na UMinho. Além destes, constam ainda assuntos de iniciativa do Conselho Geral, referentes à aprovação de atas e outros temas.

Os trabalhos começaram esta manhã, pelas 9h30, e prosseguem pela tarde. A reunião acontece no salão nobre da Reitoria, no Largo do Paço, em Braga, mas pode também ser acompanhada via streaming.

