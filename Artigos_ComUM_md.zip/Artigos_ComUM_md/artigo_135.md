---
date: 13Jul2017
author: João Pedro Quesado
image: https://www.comumonline.com/wp-content/uploads/2017/04/IMG_9316-T55-1500x1000.jpg
title: Novo reitor da UMinho é eleito a 24 de outubro
url: https://www.comumonline.com/2017/07/novo-reitor-da-uminho-e-eleito-a-24-de-outubro/
site: ComUM
description: No dia 24 de outubro, o Conselho Geral (CG) irá escolher o novo reitor da Universidade do Minho (UM).
tags: Universidade do Minho, reitor, UMinho, Reitoria, eleições
type: article
---


# Novo reitor da UMinho é eleito a 24 de outubro

## 

13Jul2017 | João Pedro Quesado

No dia 24 de outubro, o Conselho Geral (CG) irá escolher o novo reitor da Universidade do Minho (UM). Esta é a data anunciada após a publicação do edital, calendário, Comissão Eleitoral e regulamento da eleição. A eleição decorre após a audição dos candidatos no dia 23 do mesmo mês.

Com o lançamento do edital, o processo eleitoral para escolher quem ocupa o cargo de reitor inicia-se de forma oficial. As candidaturas podem ser submetidas a partir de dia 22 de julho, e estão limitadas a professores e investigadores doutorados da UMinho ou de outras instituições de ensino superior e investigação, quer nacionais, quer estrangeiras.

A Comissão Eleitoral, responsável por conduzir e supervisionar todo o processo, é presidida pelo também presidente do CG, Luís Valente de Oliveira, e constituída por Luís Amaral, Óscar Gonçalves, Victor Soares e Bruno Alcaide, presidente da Associação Académica da Universidade do Minho (AAUM) e um dos quatro representantes dos estudantes no Conselho Geral.

Rui Vieira de Castro, cabeça-de-lista de uma das candidaturas dos professores e investigadores ao CG no passado mês de março, declarou em entrevista ao ComUM estar “disponível” para “protagonizar uma candidatura à reitoria”. Questionado pelo ComUM, o atual reitor, António Cunha – que atingiu o limite de mandatos -, declara que, se essa candidatura “for consumada, terá todo o meu apoio”.

