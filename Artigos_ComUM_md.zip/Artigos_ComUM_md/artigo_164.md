---
date: 21Out2020
author: João Pedro Sousa
image: https://www.comumonline.com/wp-content/uploads/2019/10/SaraGoncalves_StartPoint4-1500x1000.jpg
title: Start Point Summit. Rui Vieira de Castro admite preocupação da UMinho com futuro profissional dos estudantes
url: https://www.comumonline.com/2020/10/start-point-summit-rui-vieira-de-castro-admite-preocupacao-da-uminho-com-futuro-profissional-dos-estudantes/
site: ComUM
description: O reitor da UMinho marcou presença na sessão de abertura da Start Point Summit 2020, que se realizou esta terça-feira em formato online.
tags: Universidade do Minho, AAUM, Empreendedorismo, Rui Oliveira, Reitor Rui Vieira de Castro, START POINT Summit, Mercado de Trabalho
type: article
---


# Start Point Summit. Rui Vieira de Castro admite preocupação da UMinho com futuro profissional dos estudantes

## O reitor da Universidade do Minho marcou presença na sessão de abertura da Start Point Summit 2020.

21Out2020 | João Pedro Sousa

A edição de 2020 da Start Point Summit aconteceu esta terça-feira num formato online. A mostra de emprego, empreendedorismo e formação da região do Minho foi promovida pela Associação Académica da Universidade do Minho (AAUM) em parceria com a Start Up Braga.

A sessão de abertura do evento decorreu durante a manhã, com a participação do presidente da AAUM, Rui Oliveira, e do reitor da Universidade do Minho (UMinho), Rui Vieira de Castro. O representante dos estudantes enalteceu a importância do evento para dar a conhecer “as transformações do mundo profissional e o modo como as carreiras podem crescer”, a partir de testemunhos de antigos alunos. Sublinhou ainda a participação de profissionais ligados a empresas multinacionais, como a Google, o Facebook ou a Revolut.

Na sua intervenção, Rui Vieira de Castro manifestou-se satisfeito pela realização do evento, que possibilita o contacto dos estudantes da UMinho com o mercado de trabalho. “A Universidade está sempre preocupada com os processos sempre complexos de transição dos estudantes para o mercado de trabalho”, salientou. Acrescentou que a universidade “está, por isso, interessada em apoiar qualquer iniciativa que possa contribuir para esse objetivo, como é o caso da Start Point”.

A Start Point Summit 2020 contou também com um Programa de Aceleração de Carreiras entre os dias 12 e 14 de outubro. O programa do evento está disponível no site da Start Point e o vídeo integral desta terça-feira pode ser visto através deste endereço.

