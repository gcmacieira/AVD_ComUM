---
date: 20Out2015
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2015/10/unnamed.png
title: Investigador da UMinho cria associação portuguesa contra bullying
url: https://www.comumonline.com/2015/10/investigador-da-uminho-cria-associacao-portuguesa-contra-bullying/
site: ComUM
description: 
tags: UMinho, Associação Anti-Bullying, Instituto de Educação
type: article
---


# Investigador da UMinho cria associação portuguesa contra bullying

## Paulo Costa, investigador da Universidade do Minho em Estudos da Criança, cria a Associação Anti-bullying com Crianças e Jovens (AABCJ), uma das primeiras em Portugal.

20Out2015 | ComUM Online

A  AABCJ tem como principais objetivos sensibilizar a população para os riscos e as consequências do bullying, organizar ações de prevenção com as escolas e os municípios, orientar e disponibilizar serviços de acompanhamento especializado a vítimas, bem como promover atividades lúdico-desportivas para aproximar os mais novos à temática.

“Queremos contribuir para que os mais jovens assumam uma atitude anti-bullying, intervindo diretamente ou denunciando situações de violência junto de professores, auxiliares, direções, diretores de turma, pais, entre outros”, afirma Paulo Costa.

O projeto surge no seguimento de um vasto trabalho de investigação levado a cabo por Paulo Costa no Instituto de Educação da UMinho, depois de ter contactado com uma situação de bullying numa das suas aulas, quando ainda era professor de Educação Física no Agrupamento de Escolas de Real em Braga.

A associação foi apresentada, publicamente, esta segunda-feira, dia 19, no Instituto Português do Desporto e da Juventude (IPDJ). em Braga.

A tomada de posse dos órgãos sociais da AABCJ realiza-se esta terça-feira, dia em que se assinala o Dia Mundial de Combate ao Bullying.

 

Ana Patrícia Magalhães

Ana Rita Martins

