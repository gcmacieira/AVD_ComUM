---
date: 01Set2023
author: Joana Antunes
image: https://www.comumonline.com/wp-content/uploads/2022/10/Jose-Costa_Universidade-do-Minho_37-1500x1075.jpg
title: Universidade do Minho soma quase 2.700 novas matrículas
url: https://www.comumonline.com/2023/09/universidade-do-minho-soma-quase-2-700-novas-matriculas/
site: ComUM
description: Dos 2.882 colocados na Universidade do Minho na primeira fase do acesso ao ensino superior, 2.699 concluiram o processo de inscrição na instituição.
tags: ensino superior, UMinho, primeira fase do concurso nacional de acesso ao ensino superior
type: article
---


# Universidade do Minho soma quase 2.700 novas matrículas

## Restam ainda 183 vagas na instituição para candidatos à segunda fase.

01Set2023 | Joana Antunes

Dos 2.882 colocados na Universidade do Minho na primeira fase do acesso ao ensino superior, um total de 2.699 concluiu o processo de inscrição na instituição. Os estudantes que conquistaram o seu lugar tiveram até dia 30 de Setembro para efectuar a respetiva matrícula.

Para a segunda fase restam ainda 183 vagas, com uma significativa parcela destinada ao curso de Engenharia Electrónica, Industrial e de Computadores. As candidaturas para a segunda etapa de admissão estão abertas até dia 5 de Setembro.

