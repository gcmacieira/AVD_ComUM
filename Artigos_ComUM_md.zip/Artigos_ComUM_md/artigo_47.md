---
date: 14Dez2016
author: João Pedro Quesado
image: https://www.comumonline.com/wp-content/uploads/2016/12/IMG_8518-1500x1000.jpg
title: Bruno Alcaide reeleito presidente da AAUM
url: https://www.comumonline.com/2016/12/bruno-alcaide-reeleito-presidente-da-aaum/
site: ComUM
description: Bruno Alcaide venceu as eleições para liderar a Associação Académica da Universidade do Minho (AAUM). O candidato da Lista A foi eleito com 59,79% dos votos. Bruno Alcaide é assim eleito para um segundo mandato à frente dos destinos da direção da AAUM.
tags: eleições AAUM, AAUM, Bruno Alcaide, eleições, Eleições AAUM 2016, Diogo Cunha, Ana Ramôa, Associação Académica da Universidade do Minho, Lista C, Lista A, Lista B
type: article
---


# Bruno Alcaide reeleito presidente da AAUM

## 

14Dez2016 | João Pedro Quesado

Bruno Alcaide venceu as eleições para liderar a Associação Académica da Universidade do Minho (AAUM). O candidato da Lista A foi eleito com 59,79% dos votos. Bruno Alcaide é assim eleito para um segundo mandato à frente dos destinos da direção da AAUM.



Bruno Alcaide encara a vitória como “o culminar de um período de campanha” no fim do qual a candidatura tinha “a certeza” que merecia “o voto de cada um deles [dos alunos] e isso mesmo expressou-se aqui na academia.” 

O presidente reeleito define como prioridades para o próximo mandato, que começa em janeiro de 2017, continuar “a defender os direitos e os interesses dos estudantes”.

Diogo Cunha reagiu dizendo que a Lista B não encara o resultado obtido “como um resultado positivo”, dado que o projeto “tinha como objetivo vencer”. E garantiu: “Isto não ficará por aqui. Estaremos durante todo o ano a acompanhar o mandato.”

Ana Ramôa, a líder da Lista C, não marcou presença na divulgação dos resultados.

Quanto aos outros órgãos de governo da AAUM, a Lista D venceu a votação para a Mesa da Reunião Geral de Alunos (RGA), enquanto a Lista G liderou as intenções de voto para o Conselho Fiscal e Jurisdicional (CFJ), obtendo cinco mandatos, seguida da Lista H, que obteve quatro.





