---
date: 18Fev2023
author: Maria Francisca Barros
image: https://www.comumonline.com/wp-content/uploads/2022/10/Jose-Costa_Universidade-do-Minho_05-1500x1000.jpg
title: 49º aniversário da UMinho celebra-se hoje em Braga
url: https://www.comumonline.com/2023/02/49o-aniversario-da-uminho-celebra-se-hoje-em-braga/
site: ComUM
description: A UMinho fez na última sexta-feira, dia 17 de fevereiro, 49 anos. Celebrações vão durar um ano com a comemoração do Cinquentenário da UM.
tags: Universidade do Minho, Guimarães, Braga, 50º aniversário da Universidade do Minho, 49º aniversário da Universidade do Minho, Ciquentenário da UMinho
type: article
---


# 49º aniversário da UMinho celebra-se hoje em Braga

## Este sábado é o grande dia das celebrações que regressam ao Largo do Paço, depois de em 2022 terem ocorrido no Theatro Jordão.

18Fev2023 | Maria Francisca Barros

A Universidade do Minho (UMinho) comemorou na última sexta-feira, dia 17 de fevereiro, 49 anos de existência. As celebrações tiveram início em Guimarães com um concerto que contou com a participação do Coro do Departamento de Música da UMinho – VianaVocale, o Coro da Academia de Música de Viana do Castelo e a Orquestra Académica da UMinho. O concerto vai se repetir este sábado (18), mas no Salão Medieval da UMinho, em Braga, pelas 21h30.

Durante o dia de sábado, as celebrações arrancam às 10h30, com as intervenções do presidente da Assembleia da República, Augusto Santos Silva, da Ministra da Ciência, Tecnologia e Ensino Superior, Elvira Fortunato, da presidente do Conselho Geral da UMinho, Joana Marques Vidal, do reitor da UMinho, Rui Vieira de Castro e da presidente da Associação Académica da UMinho, Margarida Isaías.

Na cerimónia, vai ser revelado à comunidade académica a imagem e programa das Comemorações do Cinquentenário da UMinho. Tarefa a cargo do presidente da comissão, professor João Rosas. Vão ser ainda entregues diplomas e o Prémio de Mérito Científico, bem como o título de professor emérito a José Viriato Capela e Manuel Pinto.

A sessão vai ser transmitida em direto no canal do youtube da UMinho.

