---
date: 
author: 
image: 
title: UMinho tetracampeã europeia em andebol universitário
url: https://www.comumonline.com/2015/08/uminho-tetracampea-europeia-em-andebol-universitario/
site: ComUM
description: 
tags: Andebol, Desporto Universitário, UMinho
type: article
---


# UMinho tetracampeã europeia em andebol universitário

## 

 | 

A jogar em casa, a Universidade do Minho revalidou o título de campeã universitária de andebol, ao derrotar a Universidade de Córdoba, na final, por 24-21. Em oito finais, esta foi a quarta vitória alcançada pela formação minhota.



Para chegar ao triunfo, a selecção nacional, comandanda por Gabriel Oliveira, venceu os congéneres do Instituto Politécnico de Leiria (27-13), os franceses da Universidade de Strasboug (22-27), os romenos da Universidade de Pitesti (19-38) e os espanhóis da Universidade de Córdoba (29-23) na fase de grupos, tendo perdido com os alemães da HfPV Wiesbaden (24-25).

Depois de uma primeira fase no formato de todos contra todos, UMinho e Córdoba voltaram a defrontar-se, na partida decisiva, de novo com a selecção portuguesa a terminar por cima.

O Campeonato Europeu Universitário de Andebol 2015 decorreu de 2 e 9 de agosto, em Braga, organizado pela Federação Académica do Desporto Universitário, em parceria com a Universidade do Minho e a Associação Académica da Universidade do Minho, sob a égide da Associação Europeia do Desporto Universitário (EUSA).

