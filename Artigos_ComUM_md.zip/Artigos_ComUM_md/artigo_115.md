---
date: 30Ago2023
author: Margarida da Silva Carvalho
image: https://www.comumonline.com/wp-content/uploads/2022/12/Imagem1-1.jpg
title: Mais de 15 mil camas asseguradas para universitários até 2026
url: https://www.comumonline.com/2023/08/mais-de-15-mil-camas-asseguradas-para-universitarios-ate-2026/
site: ComUM
description: A ministra da Ciência, Tecnologia e Ensino Superior anunciou a criação de mais de 15 mil camas universitárias até 2026, financiadas pelo PRR.
tags: Residências Universitárias, Plano de Recuperação e Resiliência (PRR)
type: article
---


# Mais de 15 mil camas asseguradas para universitários até 2026

## A ministra da Ciência, Tecnologia e Ensino Superior confirmou que o projeto é financiado pelo PRR.

30Ago2023 | Margarida da Silva Carvalho

A ministra da Ciência, Tecnologia e Ensino Superior, Elvira Fortunato declarou, esta terça-feira, que os estudantes universitários vão ter disponibilizadas mais de 15 mil camas até ao ano de 2026. O projeto só é possível pelo financiamento do PRR (Plano de Recuperação e Resiliência português).

De momento estão a ser construídas cerca de 86 novas residências. Elvira Fortunato destacou a importância do PRR depois de visitar uma futura residência de estudantes de Lamego, no distrito de Viseu. Afirma que o plano PRR “permitiu montar um plano nacional que vai desde o Minho até ao Algarve, incluindo também as ilhas”, acrescentado que se encontram “a construir residências em todo o país e, como é este caso aqui, utilizando até edifícios devolutos”, em zonas da cidade com “menos movimento”.

A futura residência destinada a alunos de Lamego faz parte do Plano Nacional de Alojamento no Ensino Superior financiado pela PRR em 1,5 milhões de euros (com o acréscimo de 284 mil da autarquia). A residência disponibilizará 46 camas a estudantes bolseiros a partir do ano letivo 2024/2025.

