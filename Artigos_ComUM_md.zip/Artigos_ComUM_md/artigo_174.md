---
date: 28Dez2021
author: Eduarda Almeida
image: https://www.comumonline.com/wp-content/uploads/2016/01/brinquedos.jpg
title: UMinho angaria cerca de cinco mil brinquedos para famílias mais carenciadas
url: https://www.comumonline.com/2021/12/uminho-angaria-cerca-de-5-000-brinquedos-para-familias-mais-carenciadas/
site: ComUM
description: Entre os dias 17 de novembro e 23 de dezembro, a Universidade do Minho angariou cerca de 5000 brinquedos destinados às crianças da região.
tags: natal, UMinho, Angariação de brinquedos
type: article
---


# UMinho angaria cerca de cinco mil brinquedos para famílias mais carenciadas

## A campanha de recolha já conta com treze edições.

28Dez2021 | Eduarda Almeida

Promovida pela Universidade do Minho, a campanha de recolha de brinquedos “Oferece e faz uma criança feliz!”, angariou, entre os dias 17 de novembro e 23 de dezembro, cerca de cinco mil brinquedos destinados às crianças da região. Os brinquedos foram entregues à Delegação de Braga da Cruz Vermelha Portuguesa, para serem encaminhados para as famílias mais carenciadas.

A campanha levada a cabo pelos Serviços de Ação Social da Universidade do Minho (SASUM), em cooperação com a Associação Académica da Universidade do Minho (AAUM) e com a Society Loving the Planet Minho, tem assistido a um aumento gradual da adesão por parte de empresas e instituições do Norte. Diogo Azeres, membro do Gabinete de Sustentabilidade dos SASUM, afirmou que “neste ano de 2021, foram onze as instituições parceiras que se associaram à causa e contribuíram para o sucesso da iniciativa”.

A Biblioteca Lúcio Craveiro da Silva, a Escola Secundária das Taipas, a Escola Secundária Francisco de Holanda e o Agrupamento de Escolas de Montelongo foram algumas das instituições que apoiaram a causa, em conjunto com as empresas Atepeli Ateliers e Groupe Leader.

