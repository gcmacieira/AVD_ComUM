---
date: 07Dez2021
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2021/12/DSC_0699-1500x1000.jpg
title: Duarte Lopes é o novo presidente da AAUM. Lista C é eleita para o CFJ e a Lista B é eleita para a RGA
url: https://www.comumonline.com/2021/12/duarte-lopes-e-o-novo-presidente-da-aaum-lista-c-e-eleita-para-o-cfj-e-a-lista-b-e-eleita-para-a-rga/
site: ComUM
description: Duarte Lopes, candidato pela Lista A, é o novo presidente da direção da Associação Académica da Universidade do Minho (AAUM).
tags: AAUM, eleições, RGA, CFJ, Duarte Lopes, Direção, Listas Eleitas, Vencedores
type: article
---


# Duarte Lopes é o novo presidente da AAUM. Lista C é eleita para o CFJ e a Lista B é eleita para a RGA

## O novo presidente da AAUM obteve 2.389 votos.

07Dez2021 | ComUM Online

Duarte Lopes, candidato pela Lista A, é o novo presidente da direção da Associação Académica da Universidade do Minho (AAUM). O estudante venceu Lucas Gonçalves (Lista M), com mais 1.792 votos, e Hélder Matos (Lista P), com mais 1.658 votos. David Ribeiro, da Lista B, vai presidir a mesa de Reunião Geral de Alunos (RGA) e José Diogo Soares, da Lista C, é o novo rosto do Conselho Fiscal e Jurisdicional (CFJ).

Maria Carvalho | ComUM

A Lista A conseguiu 2.389 votos. Enquanto que as Listas M e P conquistaram 597 e 731 votos, respetivamente. Os votos brancos foram 179.

Duarte Lopes, o novo presidente da direção da AAUM, já contava com este desfecho. Este resultado “demonstra uma vontade dos membros da academia para a continuação do nosso projeto”, reforça.

Para Lucas Gonçalves, a lista M foi um “movimento que começou este ano, mas certamente que vai ter continuidade de alguma forma”. Assim, reitera que a lista pretende “continuar a reivindicar os direitos e a captar muito mais a atenção dos estudantes”.

Hélder Matos considera que a direção da AAUM “não fica bem entregue”, já que a Lista P “apresenta-se como um projeto diferente”. Segundo o aluno, não se pode “dizer que a direção é reivindicativa, quando reivindica à porta fechada”.



Joana Dantas | ComUM

A Lista C, representada por José Diogo Soares, obteve 1.577 votos para o CFJ. Já a estudante Inês Batista, com a Lista E, arrecadou 1.058 votos. Assim, a Lista C conquistou assim cinco mandatos e a Lista E arrecadou quatro mandatos. O número de votos brancos foi de 274.

José Diogo Soares, presidente eleito do CFJ, afirma que se pode esperar um órgão “rigoroso e exigente”, capaz de exigir “uma ação da direção transparente e próxima dos estudantes”. O aluno explica que o conselho vai ter “o melhor de dois mundos ao juntar as bandeiras da lista C com as da lista E”. Inês Batista admite que "não conseguiu obter aquilo que pretendia, a maioria". Porém, perspetiva "um mandato de excelência".



Joana Dantas | ComUM

A Lista B, encabeçada por David Ribeiro, foi eleita com 1.363 votos. Por outro lado, a Lista D, representada por Jacinta Sampaio, conquistou 1.004 votos. O número de votos brancos foi de 262.

“O nosso maior objetivo é conseguirmos aumentar a adesão às RGAs e aumentar aquilo que é a contribuição dos alunos para estes assuntos”, expõe David Ribeiro. “Queremos debater os assuntos de forma mais dinâmica, informal e diversificada e apoiar na tomada da decisão”, adiciona.

Jacinta Sampaio afirma que a RGA "fica entregue a boas mãos". "A partir do momento em que estudantes se juntam e têm em mente criar uma lista candidata, é algo sempre de se valorizar, porque exige muita coragem", declara. "Eles claramente vão fazer um ótimo trabalho", acrescenta.



Duarte Lopes vai assumir funções no início de 2022.

Artigo por: Ana Margarida Alves 

Entrevistas: Maria Carvalho, Maria Francisca Barros e Nuno Pereira

Multimédia: Joana Dantas e Joana Oliveira

