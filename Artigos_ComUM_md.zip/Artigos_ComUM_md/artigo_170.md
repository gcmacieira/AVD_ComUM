---
date: 
author: 
image: 
title: UM promove recolha de alimentos e luta contra o desperdício
url: https://www.comumonline.com/2013/10/um-promove-recolha-de-alimentos-e-luta-contra-o-desperdicio/
site: ComUM
description: 
tags: “Menos olhos do que barriga”
type: article
---


# UM promove recolha de alimentos e luta contra o desperdício

## 

 | 

Para assinalar o Dia Mundial da Alimentação, o Departamento Alimentar dos Serviços de Ação Social da Universidade do Minho (DA-SASUM) promoveu, entre os dias 15 e 16 de Outubro, uma campanha de recolha de alimentos. A esta iniciativa juntou-se, ontem, o movimento “Menos olhos do que barriga”, que pretende lutar contra o desperdício alimentar na UM e que se irá estender durante todo o ano letivo.

Sob o tema “Um dia com o Banco Alimentar”, a campanha de recolha de alimentos teve uma adesão “relativa”, segundo a engenheira Celeste Pereira, responsável pela campanha.

Durante os dois dias, vários estudantes aderiram à iniciativa, tendo depositado os produtos alimentares nos bares da universidade, locais destinados para esse efeito.

Ana Carvalho, aluna do 3º ano da licenciatura em Estudos Portugueses e Lusófonos, faz parte do lote de estudantes que participaram nesta ação e explicou ao ComUM as razões do seu contributo. “Como é óbvio, este tipo de iniciativas tem sempre um impacto positivo na vida de muitas pessoas. Nos dias de hoje, a pobreza é uma realidade que afeta muitas famílias e a comida é um bem de primeira necessidade. Como tal, todos devemos contribuir da forma que conseguirmos”, justificou a estudante.

O movimento “Menos olhos do que barriga” surgiu depois de um estudo realizado pelo DA-SASUM sobre a quantidade de resíduos alimentares produzidos diariamente na UM.

Em entrevista ao ComUM, Celeste Pereira referiu que “o objetivo [deste movimento] é iniciar uma mudança de atitudes comportamentais relativamente ao desperdício alimentar”.

“Atendendo aos números elevados [de resíduos alimentares], achamos que tínhamos o dever de iniciar alguma atividade de sensibilização. No fundo, estamos a falar de questões ambientais e da possibilidade de ajudar algumas famílias com refeições sobrantes, desde que elas não sejam ‘desperdiçadas no prato'”, explicou.

Sabendo que a maioria dos resíduos são resultantes do desperdício dos tabuleiros, o movimento de luta contra o desperdício alimentar apela à mudança de comportamento da comunidade académica. Assim, o objetivo é que cada um leve no tabuleiro apenas a quantidade de comida que irá ingerir, para que os alimentos que não são servidos possam ser reutilizados.

Catarina Fernandes
Miguel Faria

