---
date: 06Jan2020
author: Bruna Sousa
image: https://www.comumonline.com/wp-content/uploads/2017/04/IMG_9310-T55-1500x1000.jpg
title: SASUM investem 19 mil euros nos Prémios de Mérito Desportivo
url: https://www.comumonline.com/2020/01/sasum-investem-19-mil-euros-nos-premios-de-merito-desportivo/
site: ComUM
description: Os Serviços de Ação Social da Academia Minhota (SASUM) investem 19 mil euros na 10ª edição dos Prémios de Mérito Desportivo da Universidade do Minho.
tags: Universidade do Minho, Desporto Universitário, SASUM, Prémios de mérito desportivo
type: article
---


# SASUM investem 19 mil euros nos Prémios de Mérito Desportivo

## Os Serviços de Ação Social da Academia Minhota (SASUM) investem 19 mil euros na 10ª edição dos Prémios de Mérito Desportivo da Universidade do Minho.

06Jan2020 | Bruna Sousa

O aumento do investimento dos Prémios de Mérito Desportivo, que vão ocorrer este sábado, no Restaurante Panorâmico, deve-se ao crescente número de atletas/estudantes que serão galardoados na cerimónia. Em declarações à RUM, o Diretor do Departamento de Desporto e Cultura dos SASUM, Carlos Videira, afirmou que serão cerca de 100 os atletas que conseguiram conjugar a excelência desportiva com o sucesso académico. Apesar dos dados não estarem fechados, calcula-se assim um aumento de 37 estudantes – atletas selecionados relativamente ao ano passado.

Esta edição contará com uma tertúlia com atletas olímpicos que tenham, inclusive, passado pelas competições universitárias, nomeadamente Rui Bragança (taekwondo), Susana Feitor (marcha atlética) e Filipa Martins (ginástica artística). Esta seleção serve, segundo Carlos Videira, para “inspirar os nossos atletas que ainda alimentam o sonho de chegar aos Jogos Olímpicos de 2020, em Tóquio”.

De acordo com o Regulamento de Atribuição de prémios de Mérito Desportivo aos Estudantes-Atletas da Universidade do Minho, o prémio de mérito desportivo visa apoiar financeiramente os estudantes da Universidade do Minho que obtêm resultados desportivos de excelência, nas competições internacionais universitárias e campeonatos nacionais universitários.

