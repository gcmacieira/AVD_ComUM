---
date: 23Set2021
author: Maria Francisca Barros
image: https://www.comumonline.com/wp-content/uploads/2017/10/IMG_3277-T55-e1632422468321-1500x663.jpg
title: Eleição para a reitoria da UMinho conta com duas candidaturas
url: https://www.comumonline.com/2021/09/eleicao-para-reitoria-da-uminho-conta-com-duas-candidaturas/
site: ComUM
description: Rui Vieira de Castro e Maria Clara Calheiros tiveram as suas candidaturas ao cargo de reitor da UM aceites provisoriamente pela Comissão Eleitoral.
tags: Universidade do Minho, reitor, Comissão Eleitoral, Rui Vieira de Castro, Joana Marques Vidal, Maria Clara Calheiros
type: article
---


# Eleição para a reitoria da UMinho conta com duas candidaturas

## A eleição do novo reitor está agendada para dia 27 de outubro.

23Set2021 | Maria Francisca Barros

Na última quinta-feira foram admitidas provisoriamente pela Comissão Eleitoral duas candidaturas para o cargo de reitor da Universidade do Minho. As candidaturas aceites foram apresentadas por Maria Clara Calheiros de Carvalho, professora catedrática da Escola de Direito da UM, e por Rui Vieira de Castro, atual reitor da UMinho. A informação foi divulgada à comunidade académica por Joana Marques Vidal, presidente da Comissão Eleitoral.

Foram submetidas três candidaturas para o cargo de reitor da academia minhota. No entanto, a candidatura apresentada pelo Doutor Luís Esteves foi rejeitada pela Comissão Eleitoral “por não preencher os requisitos legalmente exigidos”. Por outro lado, “as outras duas [candidaturas] encontram-se formalmente instruídas e preenchem os requisitos legalmente exigidos”, declara a nota enviada pela presidente da Comissão Eleitoral.

Deste modo, Rui Vieira de Castro e Maria Clara Calheiros de Carvalho vão disputar, no dia 27 de outubro, a eleição para reitor da Universidade do Minho. Todavia, a admissão definitiva das duas candidaturas a reitor decorre até ao dia 15 de outubro, conforme o calendário eleitoral.

