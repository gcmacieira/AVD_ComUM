---
date: 11Out2015
author: Sara Daniela
image: https://www.comumonline.com/wp-content/uploads/2015/10/02122014-DSC_0008-1500x1000.jpg
title: Universidade do Minho com um Jardim Botânico já em novembro
url: https://www.comumonline.com/2015/10/universidade-do-minho-com-um-jardim-botanico-ja-em-novembro/
site: ComUM
description: 
tags: UMinho, Jardim Botânico, Campus
type: article
---


# Universidade do Minho com um Jardim Botânico já em novembro

## A Universidade do Minho vai ter um jardim botânico dentro do campus de Gualtar. A iniciativa do departamento de Biologia da UMinho arranca já em novembro e não exclui a possibilidade de alargar a ideia aos dois campi da academia.

11Out2015 | Sara Daniela

Coordenado pela professora Fernanda Cássio, diretora adjunta do departamento de Biologia, o projeto conta ainda com a colaboração de vários docentes, nomeadamente o professor Renato Henriques, da Escola Ciências da Terra, que ficará responsável por fazer a cartografia das árvores do campus. A ideia passa por os “alunos identificarem as espécies de árvores, retirarem-nas do campus e replantarem como espécies autóctones” explicou Fernanda Cássio ao ComUM.

Para a responsável desta iniciativa, este é um projeto de toda a relevância, uma vez que “mostra uma grande preocupação ambiental e criam-se infraestruturas para o ensino e investigação que estão, a qualquer momento, à disposição dos alunos, tendo a capacidade de ensinar a baixo custo. Assim, as aulas práticas podem ser executadas no jardim botânico”.

O departamento de Biologia tenciona ainda criar um borboletário, uma espécie de estufa em rede com espécies vegetais para reproduzir borboletas. Fernanda Cássio encara esta iniciativa como algo que “para além de criar biodiversidade, pode criar momentos de lazer e de diversão. Pretendemos ainda que todo o campus seja trabalhado com o intuito de o dinamizar.”

A iniciativa pretende ainda que o espaço esteja aberto à comunidade, no qual serão realizadas ações com o ensino básico e secundário com a finalidade de dar a conhecer o projeto e o trabalho dos alunos universitários.

O projeto já foi aprovado pelo administrador da Universidade do Minho, que inclusive propôs levar a ideia até ao Pólo de Azurém. As primeiras plantações estão previstas para inícios de novembro.

