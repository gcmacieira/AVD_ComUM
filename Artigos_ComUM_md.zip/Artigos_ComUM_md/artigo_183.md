---
date: 30Ago2021
author: Maria Francisca Barros
image: https://www.comumonline.com/wp-content/uploads/2017/01/IMG_0839-T55-1500x1000.jpg
title: UMinho disponível para receber estudantes afegãos
url: https://www.comumonline.com/2021/08/uminho-disponivel-para-receber-estudantes-afegaos/
site: ComUM
description: O reitor da Universidade do Minho, Rui Vieira de Castro, anunciou à RUM que a academia minhota está disponível para receber estudantes afegãos.
tags: Universidade do Minho, RUM, Rui Vieira de Castro, refugiados afegãos, estudantes afegãos
type: article
---


# UMinho disponível para receber estudantes afegãos

## As portas da academia minhota estão abertas para receber os refugiados afegãos que chegam a Portugal.

30Ago2021 | Maria Francisca Barros

O reitor da Universidade do Minho, Rui Vieira de Castro, anunciou à RUM que a academia minhota está disponível para receber estudantes afegãos. De momento, ainda não é possível dizer se os refugiados que possam chegar à UMinho vão ou não ficar em residências universitárias.

Na conversa com a RUM, o reitor recorda também os últimos anos, em que a instituição de ensino superior minhota recebeu vários estudantes provenientes da Síria, dado ao clima de instabilidade no país. Mais uma vez, as portas da academia minhota estão abertas, agora para receber os refugiados afegãos que chegam a Portugal.

Na última sexta-feira, o Ministro do Ensino Superior, Manuel Heitor, anunciou que os refugiados afegãos que queiram continuar a frequentar o ensino superior podem vir a ter vagas disponíveis nas instituições universitárias portuguesas. No entanto, o Conselho de Reitores diz ser premente que este assunto seja tratado no âmbito diplomático.

