---
date: 01Nov2022
author: Joana Oliveira
image: https://www.comumonline.com/wp-content/uploads/2021/12/IMG_5896-scaled-e1638557448476-1500x754.jpg
title: Duarte Lopes não se recandidata à presidência da AAUMinho
url: https://www.comumonline.com/2022/11/duarte-lopes-nao-se-recandidata-a-presidencia-da-aauminho/
site: ComUM
description: O atual presidente da Associação Académica da Universidade do Minho (AAUM), Duarte Lopes, não se vai recandidatar ao cargo
tags: eleições AAUM, AAUM, RGA, Presidência, comunicado, Duarte Lopes
type: article
---


# Duarte Lopes não se recandidata à presidência da AAUMinho

## Duarte Lopes está na direção da associação desde 2019.

01Nov2022 | Joana Oliveira

O atual presidente da Associação Académica da Universidade do Minho (AAUM), Duarte Lopes, não se vai recandidatar ao cargo. O comunicado foi feito esta terça-feira, dia 1 de novembro, na sua conta pessoal da rede social Instagram.

Perto de terminar o primeiro e único mandato como presidente, Duarte Lopes fala do seu percurso como “surpreendente, pleno em obstáculos e imprevistos”. Afirma que sempre procurou o crescimento da AAUM, seja “em impacto, dimensão e atividade”. Sai “com desígnios cumpridos”, os quais pertencem a todos os estudantes que colaboraram com a associação. No entanto, refere que a AAUM “será sempre uma casa inacabada”, sendo necessária a sua “capacidade de renovação”.

O estudante de mestrado tomou posse como presidente da AAUM a 22 de janeiro deste ano, após ter vencido as últimas eleições académicas com 2.389 votos. O calendário eleitoral deste ano para a eleição dos órgãos de governo da AAUM vai ser aprovado na próxima segunda-feira, dia 7 de novembro, na Reunião Geral de Alunos.

