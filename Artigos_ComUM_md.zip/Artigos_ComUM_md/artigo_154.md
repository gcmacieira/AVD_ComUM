---
date: 07Nov2021
author: Maria Carvalho
image: https://www.comumonline.com/wp-content/uploads/2020/12/Rui-Oliveira4-1500x1000.jpg
title: Rui Oliveira não se recandidata à presidência da AAUM
url: https://www.comumonline.com/2021/11/rui-oliveira-nao-se-recandidata-a-presidencia-da-aaum/
site: ComUM
description: Rui Oliveira, atual presidente da Associação Académica da Universidade do Minho (AAUM) não se vai recandidatar para um terceiro mandato.
tags: Associação Académica da Universidade do Minho, Rui Oliveira, Presidente da AAUM
type: article
---


# Rui Oliveira não se recandidata à presidência da AAUM

## O estudante promete continuar a ser “um embaixador” da academia minhota.

07Nov2021 | Maria Carvalho

Rui Oliveira, atual presidente da Associação Académica da Universidade do Minho (AAUM) não se vai recandidatar para um terceiro mandato. O anúncio foi partilhado este sábado, na sua página de Facebook.

Em declarações à RUM, revelou que a decisão já estava tomada e surgiu após uma longa reflexão. Rui Oliveira declarou também que a comunidade estudantil “se renova muito rapidamente e essa renovação deve ser feita constantemente também nestas estruturas”. Segundo o estudante, é necessário “encontrar novas caras  com ambições renovadas”.

O estudante do Mestrado Integrado em Engenharia Mecânica iniciou o seu percurso na Associação Académica há cinco anos: três deles na presidência e os últimos dois na liderança da mesma. “Durante este período, tenho a certeza que trabalhamos para uma associação que fosse capaz de causar mais impacto na sua ação, através de melhorias na auscultação, no envolvimento, na inovação e na comunicação, bem como empenhados na melhoria do seu desempenho, pela melhor utilização de recursos e consolidação de processos”, escreve na nota.

O ato eleitoral para os novos órgãos sociais da Associação Académica vai decorrer no início da segunda semana de dezembro de 2021.

