---
date: 10Nov2023
author: Catarina Coelho
image: https://www.comumonline.com/wp-content/uploads/2021/11/Escola-de-Direito-da-UMinho.jpg
title: UMinho disponibiliza bolsas para mestrados e pós-graduações
url: https://www.comumonline.com/2023/11/uminho-disponibiliza-bolsas-para-mestrados-e-pos-graduacoes/
site: ComUM
description: A UMinho vai disponibilizar bolsas de estudo para mestrados e pós-graduações, com 283 vagas disponíveis. Delas fazem parte 39 mestrados e pós-graduações.
tags: bolsas de estudo, UMinho, pós-graduação, Mestrados
type: article
---


# UMinho disponibiliza bolsas para mestrados e pós-graduações

## São 283 as vagas disponíveis, nas quais fazem parte 39 mestrados e pós-graduações.

10Nov2023 | Catarina Coelho

A Universidade do Minho vai disponibilizar bolsas para mestrados e pós-graduações, com 283 vagas disponíveis. Esta iniciativa conta com a parceria das fundações José Neves e a Galp.

Essas mesmas bolsas são reembolsáveis e o programa ISA FJN assegura o pagamento da propina na sua íntegra. No entanto, esse investimento é apenas devolvido quando o estudante atinge as condições estabelecidas para o fazer de forma sustentada.

O número de cursos abrangidos é extenso, incluindo diversas áreas tais como ciências sociais, engenharias, saúde, moda, finanças, línguas, entre outras. O prazo para formalizar e submeter a candidatura acaba no fim este ano, ou seja, 31 de dezembro.

