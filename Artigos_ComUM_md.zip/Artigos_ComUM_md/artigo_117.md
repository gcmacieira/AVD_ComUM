---
date: 07Set2019
author: Cátia Barros
image: https://www.comumonline.com/wp-content/uploads/2017/10/IMG_3161-T55-1500x1000.jpg
title: Mais de 3.500 alunos colocaram a Universidade do Minho como primeira opção
url: https://www.comumonline.com/2019/09/mais-de-3-500-alunos-colocaram-a-universidade-do-minho-como-primeira-opcao-2/
site: ComUM
description: Na primeira fase do concurso de acesso ao ensino superior foram colocados 44.500 estudantes. O curso com média mais alta na UM é Medicina.
tags: Universidade do Minho, Medicina, Engenharia Biomédica, UM, Concurso Nacional de Acesso, Engenharia e Gestão Industrial, colocações, CNA 2019
type: article
---


# Mais de 3.500 alunos colocaram a Universidade do Minho como primeira opção

## Na primeira fase de acesso foram colocados 44.500 estudantes. O curso com média mais alta na UM é Medicina.

07Set2019 | Cátia Barros

A primeira fase do concurso de acesso ao ensino superior colocou mais de 2.820 estudantes nos cerca de 60 cursos da Universidade do Minho. A academia minhota conseguiu captar mais 40 alunos que no ano anterior. Dos 57 cursos que a UMinho oferece apenas seis têm vagas para a segunda fase.

O curso com média mais alta na academia minhota continua a ser Medicina, no campus de Gualtar (18,82 valores). Engenharia e Gestão Industrial (17,58) e Engenharia Biomédica (17.06) ocupam a segunda e a terceira posições, respetivamente. Podes consultar o resto dos resultados aqui.

Já a nível nacional, o curso de Medicina da Universidade do Minho ocupa o nono curso com a nota do último colocado mais alta. No topo da tabela encontra-se Engenharia Aeroespacial (18,95 valores).

Na primeira fase do concurso de acesso ao ensino superior público concorreram mais de 51 mil estudantes. Contudo, apenas 44.500 mil foram colocados nas universidades e politécnicos portugueses – um aumento de 502 em relação ao ano passado. No total, 87,2% dos candidatos já foram colocados, sendo que 53% dos mesmos ficaram na primeira opção.

A academia minhota foi, de acordo com os dados da tutela, a primeira opção de 3.613 alunos. Relativamente aos cursos que não preencheram as suas vagas na totalidade encontram-se Química, Optometria e Ciências da Visão, Engenharia Civil, Proteção Civil e Gestão do Território, Engenharia de Telecomunicações e Informática e Geologia.

Para os alunos colocados na Universidade do Minho, as inscrições realizam-se entre segunda-feira e sexta-feira, nos campi de Gualtar, em Braga, e Azurém, em Guimarães.



