---
date: 10Ago2021
author: Maria Carvalho
image: https://www.comumonline.com/wp-content/uploads/2021/04/179309041_4006479886094904_9090460688302548447_n-1500x953.jpg
title: Manuel Heitor acredita em ano letivo 100% presencial
url: https://www.comumonline.com/2021/08/manuel-heitor-acredita-em-ano-letivo-100-presencial/
site: ComUM
description: O ministro Manuel Heitor sublinha que as orientações vão sempre partir das autoridades de saúde, mas admite estar otimista.
tags: Manuel Heitor, pandemia, Ministro da Ciência Tecnologia e Ensino Superior, novo ano letivo, atividades presenciais
type: article
---


# Manuel Heitor acredita em ano letivo 100% presencial

## Manuel Heitor sublinha que as orientações vão sempre partir das autoridades de saúde, mas admite estar otimista.

10Ago2021 | Maria Carvalho

O ministro da Ciência, Tecnologia e Ensino Superior, Manuel Heitor, acredita que vai ser possível dar início ao novo ano letivo com atividades totalmente presenciais. Com a atenção no ritmo de vacinação contra a Covid-19, o ministro sublinha à Renascença que as orientações vão ser sempre das autoridades de saúde, mas admite que está otimista.

Manuel Heitor explica que “as orientações vão ser sempre as das autoridades de saúde e têm que ser percebidas num contexto evolutivo, mas hoje prevemos que o Ensino Superior retome atividades totalmente presenciais. As aulas começam no final de setembro e, até lá, temos que entender a evolução semana após semana”. “O quadro evolutivo [da pandemia] confirma-nos e dá-nos um cenário otimista que devemos evoluir claramente para um ensino totalmente presencial”, acrescenta.

A primeira fase do concurso nacional de acesso ao ensino superior arrancou esta sexta-feira com mais de 52 mil vagas disponíveis em cerca dez mil cursos. Esta fase de candidaturas termina a 20 de agosto e os resultados vão ser conhecidos a 27 de setembro.

