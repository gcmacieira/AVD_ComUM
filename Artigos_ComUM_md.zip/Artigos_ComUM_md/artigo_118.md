---
date: 01Nov2023
author: Filipa Ramos
image: https://www.comumonline.com/wp-content/uploads/2023/11/alojamento.jpg
title: Estudantes da UMinho organizam manifestação contra a falta de condições nas residências
url: https://www.comumonline.com/2023/11/manifestacao-contra-a-falta-de-condicoes-nas-residencias/
site: ComUM
description: Um grupo de estudantes da UMinho, incluindo comissões de residentes, lançou um abaixo-assinado e vai organizar uma manifestação.
tags: UMinho, PNAES, Gonçalo Silva, AAUMinho, Margarida Isaías, Reunião Geral de Alunos (RGA)
type: article
---


# Estudantes da UMinho organizam manifestação contra a falta de condições nas residências

## O protesto está marcado para dia 22 de novembro, pelas 14h30, junto à Reitoria da Universidade do Minho, em Braga.

01Nov2023 | Filipa Ramos

Um grupo de estudantes da Universidade do Minho (UMinho), incluindo comissões de residentes, lançou um abaixo-assinado, já subscrito por cerca de 350 alunos, e vai organizar uma manifestação, no dia 22 de novembro, às 14h30, junto à Reitoria, em Braga. O grupo exige o cumprimento do Plano Nacional de Alojamento para o Ensino Superior (PNAES), acerca das “prometidas residências” e melhorias das existentes.

Em declarações à RUM, Gonçalo Silva, porta-voz, refere que o objetivo é focar nas “dificuldades mais prementes sentidas pelos estudantes”, tanto nas “grandes insuficiências” relacionadas aos equipamentos, como nos “valores altíssimos praticados na região”. Esse descontentamento estende-se ainda à Ação Social Escolar, lamentando o aumento dos preços das senhas da cantina, a não atribuição dos complementos de alojamento e de deslocação, o atraso das atribuições de bolsas, tal como a insuficiência do seu número e valor e “a falta de um passe intermodal integrado com os municípios”.

As questões foram levadas à última Reunião Geral de Alunos, tendo sido reprovada, principalmente pela direção da Associação Académica da Universidade do Minho (AAUMinho). A presidente Margarida Isaías, por considerar o anterior incompleto, optou por apresentar um documento alternativo, na qual, algumas sugestões foram englobadas, sendo aprovado por unanimidade. Apesar desses fatores, Gonçalo Silva acredita na “união” e numa boa adesão por parte dos alunos.

 

