---
date: 13Out2021
author: Inês Batista
image: https://www.comumonline.com/wp-content/uploads/2017/10/IMG_3279-T55-1500x1000.jpg
title: Eleições. Clara Calheiros e Rui Vieira de Castro são os candidatos oficiais ao cargo de reitor
url: https://www.comumonline.com/2021/10/eleicoes-clara-calheiros-e-rui-vieira-de-castro-sao-os-candidatos-oficiais-ao-cargo-de-reitor/
site: ComUM
description: Clara Calheiros e Rui Viera de Castro são os candidatos oficiais ao cargo de reitor da UMinho. A audição pública terá lugar no dia 26 de outubro.
tags: Universidade do Minho, eleições, Rui Vieira de Castro, cargo de reitor, Clara Calheiros, audição pública, admissão oficial
type: article
---


# Eleições. Clara Calheiros e Rui Vieira de Castro são os candidatos oficiais ao cargo de reitor

## Joana Marques Vidal, presidente da Comissão Eleitoral, confirmou a admissão de ambas as candidaturas. A audição pública terá lugar no dia 26 de outubro.

13Out2021 | Inês Batista

Clara Calheiros e Rui Viera de Castro são os candidatos oficiais ao cargo máximo de gestão e representação da Universidade do Minho. O atual reitor recandidata-se ao orgão uninominal, com um projeto de continuidade. Já a opositora apresenta um novo projeto para a instituição.

A audição pública dos candidatos terá lugar no dia 26 de outubro, pelas 9h30, no Salão Nobre da Reitoria, no Largo do Paço, em Braga. A sessão será transmitida em tempo real. Conforme previsto no n.º 3 do artigo 7.º do Regulamento Eleitoral, o Edital de Admissão, bem como os documentos da candidatura, serão disponibilizados nas páginas do Conselho Geral  e da Universidade do Minho.

O mandato do cargo de reitor tem duração de quatro anos, podendo ser renovado uma vez. O reitor é coadjuvado por vice-reitores, até um máximo de quatro, e por pró-reitores, até um máximo de cinco, escolhidos e nomeados por si. Qualquer docente ou investigador numa instituição universitária ou de investigação, nacional ou estrangeira, se pode candidatar à posição.

