---
date: 13Mai2022
author: José Luís Vale
image: https://www.comumonline.com/wp-content/uploads/2019/05/josé-duque_cortejo-1-1500x1000.jpg
title: Cortejo académico volta a animar as ruas de Braga
url: https://www.comumonline.com/2022/05/cortejo-academico-volta-a-animar-as-ruas-de-braga/
site: ComUM
description: Após dois anos em suspenso, o cortejo volta agora ainda mais forte. Na última quarta feira estudantes de todos os cursos desfilaram pela cidade.
tags: Universidade do Minho, cultura, AAUM, Braga, Cortejo, Altice Forum Braga, Enterro da Gata 2022
type: article
---


# Cortejo académico volta a animar as ruas de Braga

## Após dois anos de suspensão, o cortejo volta agora ainda mais forte.

13Mai2022 | José Luís Vale

O cortejo académico é tradição obrigatória e simbólica, o que este ano não foi diferente. Caloiros e finalistas uniram-se na última quarta-feira para um último desfile, tanto para caloiros como para finalistas. Não faltaram cânticos, alegria e muita cerveja. Este ano o cortejo tinha como mote a expressão “A Gata não quer outra vez arroz”.

Assim, por por volta das 14h00, o centro de Braga testemunhou toda a cerimónia. Cada curso acompanhado do seu camião desfilou pelas ruas da cidade enquanto entoavam músicas, que prestavam uma última homenagem ao curso que os acolheu. Foram ao todo 55 os cursos que desfilaram, sem esquecer os convidados que também alegraram as ruas.

A atividade culminou na tribuna, local escolhido para a apresentação final de cada curso. Sentados nela estavam o presidente da Associação Académica da Universidade do Minho, Duarte Lopes, o Papa, Christian Caetano e o Cabido de Cardeais, prontos para mais tarde decidir o grande vencedor do cortejo académico.

Passada a tribuna, mudam-se as hierarquias e caloiros passam a novilhos. Comemora-se o fecho de um ciclo de praxe. Terminada a apresentação final cada curso dirigiu-se para o chafariz na Praça da República para um último momento entre “ex-caloiro” e “doutor”. Foi dentro do chafariz que cada curso entoou uma última música. Lavaram-se a cerveja e as lágrimas. E assim deu por terminado mais um cortejo académico e mais uma jornada nas vidas de caloiros e finalistas.

