---
date: 22Nov2023
author: Sofia de Paulo
image: https://www.comumonline.com/wp-content/uploads/2016/02/prometeu-e1569258285181.png
title: Alunos da UMinho organizam protesto pela Palestina
url: https://www.comumonline.com/2023/11/alunos-da-uminho-organizam-protesto-pela-palestina/
site: ComUM
description: O Direito de defesa do Estado de Israel frente aos hediondos ataques terroristas do Hamas a 7 de outubro tem provocado ”milhares de mortes em Gaza".
tags: manifestação, UMinho, Israel-Palestina
type: article
---


# Alunos da UMinho organizam protesto pela Palestina

## A mobilização faz parte de uma iniciativa informal de um grupo de alunos e decorrerá no dia 23 de novembro, às 16h.

22Nov2023 | Sofia de Paulo

O Direito de defesa do Estado de Israel frente aos hediondos ataques terroristas do Hamas a 7 de outubro tem provocado ”milhares de mortes em Gaza e mais de duas centenas na Cisjordânia”. O protesto considera que “a Universidade do Minho não pode ficar indiferente face aos acontecimentos na Palestina e em Israel”.

O grupo organizador da manifestação relembra que “em apenas um mês, Israel bombardeou mais Gaza do que os Estados Unidos da América bombardearam o Afeganistão durante toda a invasão do início do milénio”. Assim, os alunos convocam a comunidade académica para prestar apoio e “não se calarem” diante deste “genocídio em direto”.

O protesto será realizado no dia 23 de novembro, às 16h. Os estudantes irão concentrar-se em frente ao Prometeu para exigir que “Portugal faça todos os possíveis para contribuir para um cessar-fogo e o reconhecimento da Palestina enquanto Estado”, além de “fazerem-se ouvir por todas as vidas de civis perdidas em ambos os lados” do conflito.

