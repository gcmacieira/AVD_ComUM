---
date: 04Mar2022
author: Maria Carvalho
image: https://www.comumonline.com/wp-content/uploads/2018/04/jornadas_alunos-1500x1000.jpg
title: Universidade do Minho aprova fixação do valor das propinas para o ano letivo 2022/2023
url: https://www.comumonline.com/2022/03/universidade-do-minho-aprova-fixacao-do-valor-das-propinas-para-o-ano-letivo-2022-2023/
site: ComUM
description: A proposta do reitor da Universidade do Minho, Rui Vieira de Castro, foi aprovada com 11 votos a favor, três contra e uma abstenção.
tags: Universidade do Minho, Conselho Geral, Fixação do valor das propinas
type: article
---


# Universidade do Minho aprova fixação do valor das propinas para o ano letivo 2022/2023

## O Conselho Geral decorreu esta sexta-feira, dia 4 de março.

04Mar2022 | Maria Carvalho

A fixação do valor das propinas na Universidade do Minho (UMinho) no próximo ano letivo de 2022/2023 foi aprovada por maioria em Conselho Geral. A proposta do reitor da UMinho, Rui Vieira de Castro, foi aprovada com 11 votos a favor, três contra e uma abstenção.

No próximo ano letivo, o valor da propina para estudantes nacionais que frequentem uma licenciatura na academia minhota vai vai continuar fixada no valor máximo estipulado pelo Governo (697 euros). No caso dos mestrados, os valores variam entre os 1.250 e os 1.750 euros. Nos doutoramentos as propinas foram fixadas nos 2.750 euros.

Os estudantes da Comunidade dos Países de Língua Portuguesa (CPLP) continuam a contar com uma propina 1,25% superior ao valor em vigor para os estudantes nacionais e 1,25% inferior aos estudantes internacionais em todos os ciclos de ensino.

Os estudantes internacionais vão continuar a pagar entre 4.500 e 5.500 euros para frequentar os vários ciclos de ensino para os cursos geridos no âmbito da Escola de Arquitetura, Arte e Design, Escola de Direito, Escola de Economia e Gestão, Instituto de Ciências Sociais, Instituto de Educação e Escola de Letras, Artes e Ciências Humanas. O valor para os cursos geridos no âmbito da Escola de Ciências, Escola de Engenharia, Escola de Medicina, Escola de Psicologia, Escola Superior de Enfermagem e Instituto de Biomateriais, Biodegradáveis e Biomiméticos situam-se entre os 6.500 e os 7.500 euros.

