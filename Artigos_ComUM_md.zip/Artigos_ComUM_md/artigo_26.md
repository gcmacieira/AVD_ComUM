---
date: 06Nov2016
author: Ana Patricia Magalhaes
image: https://www.comumonline.com/wp-content/uploads/2016/11/17920.jpg
title: Aluno da UMinho distinguido com Prémio de Excelência e Coragem
url: https://www.comumonline.com/2016/11/aluno-da-uminho-distinguido-com-premio-de-excelencia-e-coragem/
site: ComUM
description: 
tags: UMinho
type: article
---


# Aluno da UMinho distinguido com Prémio de Excelência e Coragem

## 

06Nov2016 | Ana Patricia Magalhaes

Fernando Mendes, aluno de Mestrado de Engenharia Informática da Universidade do Minho, foi distinguido com o Prémio de Excelência e Coragem pela Feedzai. A distinção foi entregue no evento Pixel Camp, que decorreu de seis a oito de outubro, em Lisboa.

A empresa Feedzai atribui pela primeira vez o prémio que consiste no valor de um ano de propinas. Com o galardão, a empresa de machine learning (área da inteligência artificial) e big-data (grande armazenamento de dados) pretende valorizar e recompensar os estudantes de informática  envolvidos em projetos de relevo ou que, de certa forma, contribuam para a indústria de open-source.

Em entrevista ao ComUM, Fernando Mendes, aluno distinguido, explica que para participar no evento e para concorrer ao prémio da Feedzai é necessário desenvolver trabalho em prol da comunidade de programação. “É algo que gosto de fazer quando tenho tempo livre”, acrescenta.

Para participar contam elementos como a biografia, o pitch escrito e os trabalhos anteriores. Neste último aspeto, Fernando Mendes traz consigo uma bagagem cheia de projetos: “Fiz parte da direção do CeSIUM (Centro de Estudantes de Engenharia Informática) durante os últimos anos, ajudei a organizar conferências e hackathons, dei várias palestras pela Universidade e faço ainda parte da organização do CoderDojo Minho, uma iniciativa que procura ensinar crianças dos 7 aos 17 a programar.” O aluno desvenda, também, que atualmente está a iniciar um novo projeto de voluntariado “ainda numa fase embrionária.”

O estudante da UMinho afirma que vê o prémio como uma recompensa pelo esforço que fez no passado, confessando que não sabe que oportunidades poderão surgir no futuro.

Para além de Fernando Mendes, a Feedzai distingui Catarina Maçãs, aluna do Programa Doutoral em Ciências e Tecnologias da Informação da Universidade de Coimbra.

 

