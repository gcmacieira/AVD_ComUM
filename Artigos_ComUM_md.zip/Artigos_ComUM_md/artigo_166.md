---
date: 22Set2023
author: Jéssica Machado
image: https://www.comumonline.com/wp-content/uploads/2023/09/JessicaMachado_CaloiroAoMolho_02-1500x1000.jpg
title: Trajes e biquínis coloridos fazem cumprir a tradição do Caloiro de Molho [fotogaleria]
url: https://www.comumonline.com/2023/09/trajes-e-biquinis-coloridos-fazem-cumprir-a-tradicao-do-caloiro-de-molho/
site: ComUM
description: O evento pretende acolher, de uma forma menos convencional e mais divertida, todos os novos estudantes da Academia Minhota.
tags: AAUM, UMinho, Braga, Caloiro de Molho, Piscinas da Rodovia
type: article
---


# Trajes e biquínis coloridos fazem cumprir a tradição do Caloiro de Molho [fotogaleria]

## 

22Set2023 | Jéssica Machado

O Caloiro de Molho, organizado anualmente pela Associação Académica da Universidade do Minho (AAUMinho), pretende acolher, de uma forma menos convencional e mais divertida, todos os novos estudantes da Academia Minhota. Num dia de céu cinzento, os biquínis e as boias ganharam vida nas Piscinas da Rodovia, que se pintou com mergulhos e banhos de lama.

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

Jéssica Machado I ComUM

