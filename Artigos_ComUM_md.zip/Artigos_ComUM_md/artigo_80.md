---
date: 04Out2015
author: Liliana Malainho
image: https://www.comumonline.com/wp-content/uploads/2015/10/IMG_65801-1500x1000.jpg
title: Entrevista com Carlão: “Quando o público se identifica com as minhas letras sinto que não sou o único maluco”
url: https://www.comumonline.com/2015/10/entrevista-com-carlao-quando-o-publico-se-identifica-com-as-minhas-letras-sinto-que-nao-sou-o-unico-maluco/
site: ComUM
description: 
tags: Receção ao Caloiro, Carlão
type: article
---


# Entrevista com Carlão: “Quando o público se identifica com as minhas letras sinto que não sou o único maluco”

## Depois de Diogo Piçarra, Carlão subiu ao palco para arrasar a última noite da Receção ao Caloiro ’15. Carlão admite ter ficado muito satisfeito na apresentação do seu álbum, que diz revelar a “Tremura dos 40”. O músico editou, este ano, o primeiro disco em nome próprio, depois de projetos como “Algodão”, “Os Dias de Raiva” e o fim dos “Da Weasel”.

04Out2015 | Liliana Malainho

O que distingue o Carlão do Pacman?

Somos a mesma pessoa. Isto é muito estranho, parece que estou a falar tipo dos jogadores da bola que falam na terceira pessoa (risos). Desde criança chamam-me de Carlão. Quando os Da Weasel apareceram estávamos muito ligados à cultura norte-americana. Queríamos ser o que os nossos ídolos eram, daí arranjarmos os nomes em inglês. Eu acho que se os Da Weasel tivessem aparecido dois ou três anos depois já tinhamos confiança em nós próprios para nos chamarmos, provavelmente, a “Doninha”, para eu ser o Carlão, para o meu irmão ser o João Nobre e por aí fora, sabes? Pacman foi um nome arranjado na altura e que ficou sempre ligado aos Da Weasel. O que é facto é que eu sou o Carlão que sempre fui. Antes dos Da Weasel, depois dos Da Weasel, depois disto, eu vou ser sempre o Carlão. O Pacman é uma parte da minha vida que ficou ligada aos Da Weasel mas sou e sempre fui a mesma pessoa.

Na tua opinião, é a música que serve as palavras ou são as palavras que servem a música?

Algumas vezes eu faço coisas muito egoístas onde a música serve a palavra. O disco “Quarenta” não é o caso. Eu pedi a uma série de produtores, ao Branko, ao AGIR, ao Blue, ao Fred para fazerem músicas para este disco e não ser essa coisa da música servir a palavra sabes? Neste disco estão, mais ou menos, taco-a-taco.

De onde surgiu a vontade de gravar o disco “Quarenta”?

Surgiu um bocado na ressaca dos 5-30. Nós tivemos um ano muito fixe, em 2014, e toda a gente tinha coisas para fazer. O Regula tinha um novo disco, o Fred estava a trabalhar em trinta mil projetos e eu de repente fiquei com uma pica enorme e senti que tinha de fazer um disco. Só mais tarde, quando o projeto já estava avançado, é que me lembrei do nome “Quarenta” porque ia fazer quarenta anos este ano. A “cena” foi fazer algo que me desse pica. Toda a minha vida tenho seguido sempre a minha intuição e o feeling. Muitas vezes não corre bem mas em relação à música corre quase sempre. Tento ir sempre atrás disso. Se sinto uma coisa, faço. Se não sinto, não faço. Na música é sempre assim. Senti vontade, falei com pessoal e “bora aí”, fizemos o disco.

 

O single “Os Tais” apresenta uma fusão entre o kizomba e o rap. De que forma essa fusão se adequa à letra em si?

Há várias perspetivas. Numa perspetiva puramente estética, quando ouvi o tema achei-o bom mas pensei que não podia cantar por cima, ainda que aquele tipo de kizomba seja muito básico, muito diferente. Fiquei um bocado “naquela” mas senti que estava ali uma boa canção. Comecei a pensar – porque eu penso demasiado – que o pessoal ia pensar que era uma “cena” do momento, de entrar na onda do kizomba e do comercial. Até que cheguei a uma altura em que me questionei a mim mesmo se gostava da música, se fazia sentido, se era bom para mim. Cheguei à conclusão que sim, que era bom, que era fixe e que gostava. Portanto, não tive medo. Quando algo é forçado, provavelmente, não ia dar bom resultado. Eu sabia que o Branko me ia dar um beat diferente, fora da minha zona de conforto. Não estava à espera daquele beat, confesso, mas quando ele me mostra e eu meto a voz senti que resultava. Foi das músicas que fiz mais rapidamente: escrevi a letra numa manhã.

Tens de seguir a tua intuição! Há muita gente que eu sei que vai odiar mas isso faz parte. Acontecia o mesmo nos Da Weasel. Temas como Dialetos da Ternura e Retratamento foram temas muito criticados quando os álbuns saíram mas, quando ouviam o resto do disco, ficavam a gostar. Acho que o mais importante é que tu curtas. Se faz sentido, vais curtir, se não fizer sentido vais sentir remorsos e isso eu não faço.

O teu disco revela a ternura dos quarenta?

(Risos) Revela a tremura dos quarenta. Ya, a tremura… (Risos).

Sentes que as tuas letras inspiram o teu público?

Sim. Não é uma coisa automática mas tenho um bom feedback nesse sentido. As pessoas que significam mais para mim na música são precisamente aquelas que escrevem letras com as quais eu me identifico. Há pessoas que se identificam um bocado com aquilo que eu escrevo e isso deixa-me satisfeito. Eu não tento ensinar seja o que for, é apenas uma partilha. A partir do momento em que há uma identificação sentes que não és o único maluco. Não sou o único a pensar assim, a sentir-me desta forma. Não tento influenciar, eu tento fugir a isso, embora às vezes seja mais forte do que eu. Ainda assim, vou deixar isso para as minhas filhas não para o pessoal que ouve a minha música.

Para terminar, produziste diamantes esta noite?

(Risos) Ora bem, no sentido da letra, não. Acho que não vou produzir mais diamantes e, inclusive, vou fazer uma vasectomia (risos). Não sei, eu acho que ganhei novos fãs. À medida que vamos tocando este disco, temos recordado malta nova. As pessoas conhecem um single, ouvem o resto do disco e tenho tido um bom retorno. Fico muito satisfeito, por exemplo, por ter puxado pelo Bruno para o disco e para o concerto. Eh pa, e o “gajo” dá uma força inacreditável, tem uma voz belíssima! É uma ótima pessoa. Obviamente não produzi esse diamante, mas acho que o apanhei e ele produz-se a ele próprio. Isso fiz! Ya, ya… O Bruno é o diamante!

