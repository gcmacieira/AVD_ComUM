---
date: 
author: 
image: 
title: UMinho mantém valor da propina no próximo ano letivo
url: https://www.comumonline.com/2015/05/uminho-mantem-valor-da-propina-no-proximo-ano-letivo/
site: ComUM
description: 
tags: Universidade do Minho, ensino superior, AAUM, UMinho, propinas
type: article
---


# UMinho mantém valor da propina no próximo ano letivo

## 

 | 

A Universidade do Minho não vai aumentar a propina para 2015/2016. Pelo terceiro ano consecutivo, o valor vai manter-se nos 1037,20 euros para o 1.º ciclo de estudos e mestrado integrado.

A Associação Académica da Universidade do Minho (AAUM) “saúda esta decisão do Reitor da UMinho” e refere que a manutenção da verba é algo “que não se pode dissociar de um trabalho constante de reivindicação e de defesa dos interesses dos estudantes”.

Numa nota enviada à comunicação social, a AAUM salienta que a “UMinho reconhece assim o contexto socioeconómico adverso da região em que está inserida e demonstra sensibilidade face às dificuldades dos seus estudantes e respetivas famílias”, defendendo ainda que o atual valor é “demasiado elevado face aos rendimentos médios das famílias portuguesas”.

O Reitor da UMinho, António Cunha, vai formalizar a proposta de fixação das propinas na academia minhota na próxima segunda-feira, 25 de maio, em reunião do Senado Académico.

De salientar que, por lei, o valor máximo das propinas nas universidades portuguesas para o próximo ano letivo é de 1067 euros. À semelhança dos últimos dois anos, a UMinho congela assim o valor para 2015/2016.

