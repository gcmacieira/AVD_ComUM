---
date: 03Out2015
author: Sara Viana
image: https://www.comumonline.com/wp-content/uploads/2015/10/IMG_3991-1500x1000.jpg
title: Entrevista com AGIR: “Os prémios dados pelo público são sempre os mais importantes”
url: https://www.comumonline.com/2015/10/entrevista-com-agir-os-premios-dados-pelo-publico-sao-sempre-os-mais-importantes/
site: ComUM
description: 
tags: Receção ao Caloiro, Agir
type: article
---


# Entrevista com AGIR: “Os prémios dados pelo público são sempre os mais importantes”

## No segundo dia da Receção ao Caloiro ’15 foi ao músico AGIR que coube a missão de animar os alunos minhotos. O ComUM esteve à conversa com o artista português  e conseguiu saber quem lhe "partia o pescoço"

03Out2015 | Sara Viana

Qual é a sensação de pisares o palco da Receção ao Caloiro em Guimarães?

É uma estreia. Espero um dia ainda poder voltar em produção própria. Eu sei que isto está ligado à Receção ao Caloiro mas não estava à espera. Eu cheguei mesmo à hora do concerto e ainda não tinha pisado o palco. Só quando subi as escadinhas é que vejo que o palco ainda era grande. Pensei que era um palco mais modesto mas ainda me cansou, é um palco grande.

A noite correspondeu às tuas expectativas? 

Sim, sim. Espero que eu tenha superado as expectativas da malta que me tenha vindo ver. O concerto acabou com toda a gente a cantar as músicas portanto correu bem.

Quem é a rapariga que te faz partir o pescoço?

Neste momento existe mesmo uma rapariga, a minha namorada. Mas é uma situação que acontece com todos os homens quando vão a andar na rua e têm de partir o pescoço assim sem ela ver. Faz parte, desde que seja só partir o pescoço.

 

Ana João Oliveira/ComUM

Qual é a sensação de estar nomeado para os MTV EMA na categoria Best Portuguese Act ao lado de grandes músicos portugueses como Carlão e Richie Campbell?

Foi uma surpresa, não estava de todo à espera. Foi o Diogo da MTV, que por acaso é meu amigo, e me ligou: “Olha puto, tás nomeado” e eu “Boa, fixe, tass bem”. Eu dou bastante valor a este concurso porque a votação é a do público. Gosto que seja assim porque quer dizer que o nosso trabalho está a ser reconhecido, que as pessoas gostam de nós. Acho que os prémios dados pelo público são sempre os mais importantes.

“Se o tempo é dinheiro”, qual é o conselho que tens para dar aos estudantes que estão a iniciar este novo período das suas vidas?

Lá está, tempo é dinheiro. Não percam tempo. Cometam erros, é algo normal mas percebam rápido que os estão a cometer e não demorem seis meses ou um ano a percebê-lo. Sejam metódicos porque acho que nada se faz sem estratégia. Mas se a estratégia for a errada, percebam isso num espaço de um mês ou dois e mudem. Deixem um bocado um coração de parte e percebam o que estão realmente a fazer.

 

