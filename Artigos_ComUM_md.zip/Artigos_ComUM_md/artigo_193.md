---
date: 10Out2015
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2015/10/FOODNUTRITIONAWARDS_HORIZONTAL-642x336.jpg
title: UMinho premiada por tecnologia alimentar inovadora
url: https://www.comumonline.com/2015/10/uminho-premiada-por-tecnologia-alimentar-inovadora/
site: ComUM
description: 
tags: UMinho, Nutricap, Engenharia Biomédica
type: article
---


# UMinho premiada por tecnologia alimentar inovadora

## O Centro de Engenharia Biológica (CEB) da EEUM desenvolveu uma tecnologia inovadora que permitirá incrementar o valor nutricional dos produtos alimentares. Este projeto - denominado “Nutricap” - foi destacado com o prémio Food & Nutricion Award para a Investigação & Desenvolvimento.

10Out2015 | ComUM Online

Na prática esta tecnologia permite à industria alimentar desenvolver produtos fortificados com antioxidantes, vitaminas e fitosteróis. “A ideia é dar ao consumidor, cada vez mais exigente, produtos mais saudáveis e nutritivos”, realça o investigador Miguel Cerqueira, que contou com a ajuda de Ana Bourbon, Ana Pinheiro, António Vicente, Hélder Silva e Phillipe Ramos neste projeto.

“O Nutricap, que usa proteínas do leite, permite incorporar compostos bioativos solúveis e insolúveis em água, funcionando como um veículo para a libertação controlada e localizada dos compostos, distinguindo-se por apenas recorrer a substâncias naturais e de grau alimentar”, esclarece. A Improveat, spin-off da UMinho com sede no SpinPark, nas Caldas das Taipas, Guimarães, já tem explorado o potencial desta inovação.

O investigador da academia minhota destaca ainda a importância do prémio para a equipa de investigadores que tem trabalhando no projeto. “É demonstrador do excelente trabalho desenvolvido ao longo dos últimos anos pelo CEB e um incentivo muito importante para continuar a investigação neste âmbito”, esclarece Miguel Cerqueira.

O prémio Food & Nutricion foi atribuído no âmbito da 6ª edição do Food & Nutrition Awards, em Lisboa, destacando os benefícios que o setor agroalimentar demonstra em termos de empreendedorismo, competitividade e investigação.

Fábio Moreira

Beatriz Brasil

