---
date: 05Dez2022
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2022/10/Jose-Costa_Universidade-do-Minho_05-1500x1000.jpg
title: VoxPop. O que sabem os estudantes sobre as eleições da AAUM?
url: https://www.comumonline.com/2022/12/voxpop-o-que-sabem-os-estudantes-sobre-as-eleicoes-da-aaum/
site: ComUM
description: Amanhã, 6 dezembro, os alunos vão poder votar. Hoje, o ComUM andou pela UMinho para perceber o que os estudantes realmente sabem a um dia das eleições.
tags: Universidade do Minho, vox pop, Estudantes, Voto, Eleições AAUM 2022
type: article
---


# VoxPop. O que sabem os estudantes sobre as eleições da AAUM?

## Ato eleitoral decorre na próxima terça-feira, dia 6 de dezembro.

05Dez2022 | ComUM Online

Estão a decorrer as eleições para a Associação Académica da Universidade do Minho (AAUMinho). Em jogo, há seis listas que se candidatam aos diferentes órgãos. Lista C e D para o Conselho Fiscal e Jurisdicional (CFJ), lista E e B para a Mesa da Reunião Geral de Alunos e lista A e M para a Direção.

Amanhã, 6 dezembro, os alunos vão poder votar nos candidatos que acham merecedores. Mas hoje, o ComUM andou pela Universidade do Minho para perceber o que os estudantes realmente sabem a um dia das eleições.



Entrevistas por: Maria Francisca Barros e Marta Rodrigues

Edição: Maria Francisca Barros

