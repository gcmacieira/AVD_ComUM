---
date: 08Set2023
author: André Igreja
image: https://www.comumonline.com/wp-content/uploads/2023/09/41460494125491c24473_base.jpg
title: António Costa anuncia a devolução de propinas e outras medidas direcionadas para os jovens
url: https://www.comumonline.com/2023/09/antonio-costa-anuncia-a-devolucao-de-propinas-e-outras-medidas-direcionadas-para-os-jovens/
site: ComUM
description: O primeiro-ministro António Costa avançou na quarta-feira que o Governo irá devolver as propinas pagas pelos estudantes no ensino superior público.
tags: ensino superior, António Costa, Proprinas
type: article
---


# António Costa anuncia a devolução de propinas e outras medidas direcionadas para os jovens

## Para além da devolução de propinas e de descontos no IRS Jovem, o primeiro-ministro promete incentivos ao uso dos transportes públicos e consumo de cultura.

08Set2023 | André Igreja

O primeiro-ministro António Costa avançou na quarta-feira, dia 6 de setembro, que o Governo irá devolver as propinas pagas pelos estudantes no ensino superior público. Num discurso na Academia Socialista, o secretário-geral do PS divulgou um leque de medidas voltadas para os jovens, com o objetivo de os fixar no país, de entre as quais fazem também parte reformas no IRS Jovem.

Na rentrée do partido, que começou na noite de quarta-feira e decorre até domingo em Évora, o governante começou por anunciar a devolução do valor de um ano de propinas pagas numa universidade pública do país por cada ano de trabalho, correspondente a 697 euros. Uma vez que os valores das propinas dos mestrados variam, António Costa declarou que para esses casos o executivo fixou o valor em 1.500 euros.

O primeiro-ministro do governo da maioria socialista adiantou ainda que o acesso ao IRS Jovem vai sofrer alterações, salientando que “no primeiro ano em que as pessoas declaram o seu rendimento, o IRS será zero e haverá total isenção de IRS para que todos possam começar o início da sua vida”. No segundo ano, os beneficiários da iniciativa pagarão 25% do valor original do IRS, no terceiro e no quarto só pagarão metade e no quinto ano “pagarão 75% do imposto que teriam de pagar”.

A partir de janeiro do próximo ano os passes de transporte passarão a ser gratuitos para as crianças e jovens até aos 23 anos, de acordo com a intervenção de António Costa. Perante dezenas de jovens, o chefe de Governo em funções desde 2015 concluiu reforçando o incentivo ao uso dos transportes públicos com a oferta de quatro bilhetes de viagem na CP e uma semana em pousadas de juventude através de um passe especial, assim como a aposta no consumo de cultura com a entrega de um “cheque-livro” a cada jovem que celebre 18 anos.

 

 

 

