---
date: 19Abr2023
author: Marta Ferreira
image: https://www.comumonline.com/wp-content/uploads/2019/09/JorgeSousa_Pavilhão-1500x1000.jpg
title: AAUMinho promove campanha de doação de sangue para alunos
url: https://www.comumonline.com/2023/04/aauminho-promove-campanha-de-doacao-de-sangue-para-alunos/
site: ComUM
description: A Associação Académica da Universidade do Minho (AAUMinho) volta a realizar a campanha “Heróis de Capa Negra”, para promover a doação de sangue,
tags: UMinho, Campus de Gualtar, Associação Académica da Universidade do Minho (AAUM), Doação de sangue
type: article
---


# AAUMinho promove campanha de doação de sangue para alunos

## Iniciativa “Heróis de Capa Negra” decorre esta quarta e quinta-feira no Campus de Gualtar.

19Abr2023 | Marta Ferreira

A Associação Académica da Universidade do Minho (AAUMinho) volta a realizar a campanha “Heróis de Capa Negra”, para promover a doação de sangue por parte dos estudantes. Os alunos interessados podem participar na colheita entre as 9h30 e as 17h30 desta quarta e quinta-feira, no Pavilhão Desportivo do Campus de Gualtar.

Na semana passada, a mesma iniciativa ocorreu no Campus de Azurém, também a cargo da Associação Académica da UMinho. A academia minhota acolhe, desde 1999, várias campanhas de dádivas de sangue, de modo a promover o aumento das reservas de sangue em Portugal e ajudar os hospitais. A última campanha registada contou com 411 inscrições e 261 doadores.

