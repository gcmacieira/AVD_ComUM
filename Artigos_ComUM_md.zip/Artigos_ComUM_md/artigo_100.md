---
date: 
author: 
image: 
title: Guimarães recebe exposição dos 40 anos da Universidade do Minho
url: https://www.comumonline.com/2014/03/guimaraes-recebe-exposicao-dos-40-anos-da-universidade-do-minho/
site: ComUM
description: 
tags: Universidade do Minho
type: article
---


# Guimarães recebe exposição dos 40 anos da Universidade do Minho

## 

 | 

Depois de Braga receber a exposição itinerante comemorativa dos 40 anos da Universidade do Minho (UM), é a vez de Guimarães acolher a exposição, até 17 de abril, no Largo Cónego José Maria Gomes, em frente ao edifício da autarquia vimaranense.

Serão sete os concelhos da região que, até agosto, irão acolher a exposição composta por 12 estruturas onde, além da UM, estão representadas as unidades orgânicas de ensino e investigação da universidade.

A exposição itinerante tem como objetivos dar a conhecer as estruturas da universidade e ainda demonstrar a importância da educação e investigação.

Em abril a exposição segue para Famalicão, passando nos meses seguintes por Barcelos, Viana do Castelo, Ponte de Lima e Póvoa do Varzim.

