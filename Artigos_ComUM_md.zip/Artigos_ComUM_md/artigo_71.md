---
date: 05Dez2022
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2022/12/imagem-1-1500x1271.jpg
title: Eleições AAUM. A campanha eleitoral no campus universitário [fotogaleria]
url: https://www.comumonline.com/2022/12/eleicoes-aaum-a-campanha-eleitoral-no-campus-universitario-fotogaleria/
site: ComUM
description: As eleições para os órgãos de governo da Associação Académica da Universidade do Minho (AAUM) acontecem esta terça-feira, dia 6 de dezembro.
tags: CFJ, fotogaleria, campanha eleitoral, Direção, Eleições AAUM 2022, Mesa da RGA
type: article
---


# Eleições AAUM. A campanha eleitoral no campus universitário [fotogaleria]

## 

05Dez2022 | ComUM Online

As eleições para os órgãos de governo da Associação Académica da Universidade do Minho (AAUM) acontecem esta terça-feira, dia 6 de dezembro. A campanha eleitoral iniciou-se na semana passada, a 29 de novembro, e terminou este domingo, dia 4 de dezembro. A segunda-feira ficou reservada para a reflexão dos estudantes.

Na corrida ao lugar da direção, encontram-se duas listas – A e M. Ao Conselho Fiscal e Jurisdicional, estão a concorrer a lista C e a lista D. Por último, a Mesa da Reunião Geral de Alunos conta com duas listas candidatas, a E e a B.

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

Joana Oliveira | ComUM

