---
date: 
author: 
image: 
title: Faltas de ética podem gerar expulsão e anulação de graus
url: https://www.comumonline.com/2013/10/faltas-de-etica-podem-gerar-expulsao-e-anulacao-de-graus/
site: ComUM
description: 
tags: 
type: article
---


# Faltas de ética podem gerar expulsão e anulação de graus

## 

 | 

O plágio, a fabricação e a falsificação de resultados foram alguns dos principais temas debatidos numa jornada sobre “Integridade Académica: Procedimentos Éticos e Situações de Conduta Imprópria”. A iniciativa, realizada esta quarta-feira, dia 2 de outubro, no campus de Gualtar, foi organizada pela Comissão de Ética da Universidade do Minho (CEUM).

Em destaque nesta jornada estiveram as consequências académicas e legais decorrentes de condutas impróprias, que podem sancionar os autores e mesmo a universidade. Como exemplo destas consequências, o presidente da Comissão de Ética, Licínio Chainho Pereira, destaca a “expulsão” da instituição académica e a“cassação de graus”.

Com esta iniciativa, a CEUM espera poder fortificar a “integridade académica” e prevenir casos de conduta imprópria, como a fabricação, falsificação e plágio (FFP). No entanto, o aluno de mestrado em Finanças, Rui Salgado, considera que a jornada “não foi completamente direta ao assunto”, tendo-se focado mais “na publicação de resultados e na demonstração daquilo que está a ser feito”.

Em entrevista ao ComUM, o presidente da CEUM e ex-reitor da UMinho esclarece que “a Comissão de Ética dá pareceres ao reitor sobre situações de ética ou falha de ética que apareçam na Universidade”. Recordando a sua experiência como professor, Chainho Pereira afirma que no seu tempo havia “má conduta ética especialmente nos exames”.

O presidente da CEUM confessa que esperava mais adesão, especialmente por parte de professores e investigadores. Ainda assim, considera que o debate foi pautado por “bastantes perguntas”, que deram à comissão “ideias para melhorar o programa nos próximos meses”.

Inês Mendes
Silvana Valente

