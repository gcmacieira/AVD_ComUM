---
date: 03Out2021
author: Inês Batista
image: https://www.comumonline.com/wp-content/uploads/2021/10/Teatro-2-1500x844.jpg
title: Projeto da UMinho ajuda à inclusão de doentes mentais
url: https://www.comumonline.com/2021/10/projeto-da-uminho-ajuda-a-inclusao-de-doentes-mentais/
site: ComUM
description: O projeto “Romper – Arte e Saúde Mental”, da Universidade do Minho, visa desmistificar e ajudar na reabilitação psicossocial.
tags: Universidade do Minho, IrRomper, Romper - Arte e Saúde Mental~
type: article
---


# Projeto da UMinho ajuda à inclusão de doentes mentais

## A iniciativa pretende combater o estigma associado à saúde mental.

03Out2021 | Inês Batista

“Romper – Arte e Saúde Mental” estreou a peça de teatro “IrRomper”, este domingo, no Porto. José Eduardo Silva, docente de Teatro e investigador do Centro de Estudos Humanísticos da Universidade do Minho, é o coordenador do projeto que visa desmistificar e ajudar na reabilitação psicossocial. A sessão ocorreu às 18h00, no auditório do Centro Paroquial de Aldoar. Contudo, o espetáculo tem reposição a 9 e 16 de outubro, à mesma hora.

Os protagonistas são oito pessoas com perturbações mentais e dois atores. Os oito participantes referidos foram os mais envolvidos na escrita da narrativa, misturando experiências reais e ficção. José Eduardo Silva referiu que estavam todos “muito entusiasmados”. “Podem exprimir-se livremente e os métodos teatrais de improviso potenciam o seu desenvolvimento pessoal, a autonomia e as suas mensagens, ajudando a afastar preconceitos sobre as suas doenças e abrindo horizontes”, explicou.

“Romper – Arte e Saúde Mental” é o resultado de um trabalho que demorou um ano a ser concluído. A iniciativa teve financiamento de 40 mil euros da Direção-Geral das Artes e a parceria das associações Apuro, Encontrar+se e Vozes de Esperança. Está agendada uma conferência, no dia 9 de outubro, às 15h30; a estreia de um documentário de Francisco Lobo, às 17h00 do dia seguinte; e o lançamento do livro “Romper – Teatro e Saúde Mental”, de Rui Spranger, a 17 de outubro, às 18h00.

