---
date: 11Mai2023
author: Marta Rodrigues
image: https://www.comumonline.com/wp-content/uploads/2023/05/Cortejo_MartaRodrigues5-1500x1000.jpg
title: Cortejo 2023. O fechar de um ciclo [fotogaleria]
url: https://www.comumonline.com/2023/05/cortejo-2023-o-fechar-de-um-ciclo-fotogaleria/
site: ComUM
description: Esta quarta-feira, dia 10 de maio, realizou-se o Cortejo Académico da Universidade do Minho, momento que para muitos marca o fim de um ciclo.
tags: Universidade do Minho, Enterro da Gata, fotogaleria, 2023, Cortejo académico
type: article
---


# Cortejo 2023. O fechar de um ciclo [fotogaleria]

## 

11Mai2023 | Marta Rodrigues

Esta quarta-feira, dia 10 de maio, realizou-se o Cortejo Académico da Universidade do Minho, momento que para muitos marca o fim de um ciclo. Os caloiros e os finalistas festejaram pelas ruas de Braga, acompanhados de música, cerveja e animação.

Todos os cursos da academia minhota marcaram presença, formando um longo desfile de camiões alusivos a cada licenciatura. Ao chegar à Avenida Central, os caloiros performaram as apresentações que tinham preparado para o Cabido de Cardeais e para a presidente da Associação Académica da Universidade do Minho, Margarida Isaías. Passada a varanda, os estudantes celebraram com a típica entrada na fonte.

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

