---
date: 21Dez2023
author: ComUM Online
image: https://www.comumonline.com/wp-content/uploads/2023/12/AAUMinho-46-anos-1500x999.jpg
title: AAUMinho celebra o 46º aniversário
url: https://www.comumonline.com/2023/12/aauminho-celebra-o-46o-aniversario/
site: ComUM
description: No dia 19 de dezembro o Salão Medieval da Reitoria da Universidade do Minho foi o palco principal da celebração dos 46 anos da AAUMinho.
tags: Rui Vieira de Castro, AAUMinho, 46º aniversário, Margarida Isaías, Maria João Soares
type: article
---


# AAUMinho celebra o 46º aniversário

## Concerto de Maria João Soares acompanhou a cerimónia.

21Dez2023 | ComUM Online

Durante a tarde desta terça-feira, dia 19 de dezembro, o Salão Medieval da Reitoria da Universidade do Minho foi o palco principal da celebração dos 46 anos da Associação Académica da Universidade do Minho. A atual presidente da associação, Margarida Isaías, foi a primeira a discursar.

A aluna de medicina abordou assuntos de extrema importância tais como o combate ao abandono escolar, a ação social, a prevenção do assédio, o acesso ao ensino superior, as residências universitárias, as propinas e o aumento das bolsas de estudo, entre outros. Chama à atenção da falta de apoios em setores como a cultura, o desporto, a alimentação, o alojamento com o decréscimo da baixa qualidade e afirma que é preciso “passar das palavras a ações”. “Amanhã é o agora” é mote que guia o trabalho desta associação. Margarida Isaías reforça que “sem a ação social, a cultura, o desporto, a criação e o empreendedorismo não há estudantes” e que “a universidade é um espaço de discussão, reflexão, oportunidades e de construção de cidadãos”.

O evento prosseguiu com uma homenagem ao recentemente falecido António Guimarães Rodrigues, reitor da Universidade do Minho, nos anos de 2002 a 2009. Foi transmitido um vídeo no qual colegas, familiares e estudantes relembraram o professor, a sua vida, tanto pessoal como profissional, salientando o seu impacto na universidade. Foi descrito como um “reitor difícil de repetir” e um “líder carismático”. Rui Vieira de Castro, o atual reitor, define-o utilizando 3 palavras: “Dedicação”, “Rigor” e “Exemplo” e realça, ainda, a sua proximidade com a comunidade estudantil.

Foi dada a palavra a Pedro Soares, antigo membro e presidente da associação académica nos anos 2007 a 2009. No seu discurso, o ex-estudante relembrou a sua última intervenção enquanto presidente da AAUMinho, na qual, em Reunião Geral de Alunos, deu o título de membro honorário da associação a Guimarães Rodrigues, “um reitor irrepetível” e, acima de tudo o resto, “amigo”.

A convite da AAUMinho, Maria João Soares, aluna do 2º ano de Educação Básica e participante no programa televisivo The Voice, aqueceu o salão com a sua performance musical. Interpretou “Rancho fundo”, “Riptide” e “Canção de engate”, música famosa por ser, por vezes, associada à vida universitária. A atuação contou com o apoio do público, já que “não é um concerto de mim para vocês, é um concerto em conjunto”, nas palavras da artista.

 

Artigo escrito por: Catarina Coelho e Catarina Fernandes

