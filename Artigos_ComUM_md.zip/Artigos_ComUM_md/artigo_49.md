---
date: 
author: 
image: 
title: Centenas de alunos trabalham na Universidade do Minho
url: https://www.comumonline.com/2014/03/centenas-de-alunos-trabalham-na-universidade-do-minho/
site: ComUM
description: 
tags: Universidade do Minho
type: article
---


# Centenas de alunos trabalham na Universidade do Minho

## 

 | 

A Universidade do Minho (UM) tem todos os anos entre 200 a 400 estudantes a trabalhar nas suas instalações. Esta é uma forma encontrada pelos alunos para ajudar a pagar os estudos. Em troca dos serviços prestados, os estudantes recebem uma bolsa de colaboração, cujo valor assenta em três euros à hora, podendo também ser atribuída em títulos de refeição.

A cantina, o ginásio e os bares dos complexos pedagógicos são algumas das instalações que recebem anualmente alunos para trabalhar. Cátia Silva, aluna do mestrado em Ciências da Comunicação, colabora atualmente na Direção de Tecnologias e Sistemas de Informação. Esta colaboração abriu apenas este ano, e consiste em digitalizar “todos os processos dos anos, para que fique tudo informatizado”, como refere a estudante.

A aluna licenciada em Ciências da Comunicação admite que o dinheiro não foi a única razão que a levou a candidatar-se ao programa: “O meu mestrado é em regime noturno e tenho muito tempo livre”.

Já Rita Mota, estudante de Línguas Aplicadas, aponta como principais vantagens em trabalhar na universidade  “os custos de transportes e a facilidade de conjugar os trabalhos com as aulas”. No entanto, a aluna confessa que alguns “professores não se mostram flexíveis”, quanto à sobreposição de aulas e trabalho. A estudante, que já colaborou num dos bares dos complexos pedagógicos, destaca esta oportunidade, sobretudo, “como uma maneira acessível de compensar a carteira”.

Em entrevista ao Porto Canal, o administrador dos Serviços de Ação Social, Carlos Silva, referiu que o programa de colaboração de estudantes na UM é “o maior fundo que a universidade dispõe ao estudante”.

Para não interferir nas atividades escolares e possibilitar a rotatividade dos estudantes abrangidos, a colaboração não vai além das cinco horas diárias e as 20 horas semanais.

A colaboração de estudantes na UM é aberta a todos os alunos, ainda que a seleção  seja feita consoante vários parâmetros.

Carolina Guimarães
Catarina Fernandes

