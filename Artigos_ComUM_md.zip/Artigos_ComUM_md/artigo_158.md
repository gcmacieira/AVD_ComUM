---
date: 25Fev2024
author: Elisa Siquara
image: https://www.comumonline.com/wp-content/uploads/2024/02/IMG_5047-1500x1000.jpg
title: Semana da Euforia 2024 – Mais um ano de festa
url: https://www.comumonline.com/2024/02/semana-da-euforia-2024-mais-um-ano-de-festa/
site: ComUM
description: 
tags: 
type: article
---


# Semana da Euforia 2024 – Mais um ano de festa

## 

25Fev2024 | Elisa Siquara

Nos dias 19 a 22 de Fevereiro, a Academia Minhota esteve eufórica com o evento realizado pela Associação Académica da Universidade do Minho (AAUM), pelos núcleos e comissões de festa da Universidade. A programação diversa possuía atividades para todos os gostos e contou com torneios de Beer Pong, Just Dance, Sueca, festas temáticas, karaoke, atuações, cinema, entre outros.

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

Elisa Siquara I ComUM

 

