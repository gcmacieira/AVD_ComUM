---
date: 04Ago2023
author: Margarida da Silva Carvalho
image: https://www.comumonline.com/wp-content/uploads/2018/12/Stock-1019-1500x1000.jpg
title: 8ª edição do Encontro dos Alumni UMinho prevista para 16 de setembro
url: https://www.comumonline.com/2023/08/8a-edicao-do-encontro-dos-alumni-uminho-prevista-para-16-de-setembro/
site: ComUM
description: A 8ª edição do Encontro Caixa Alumni UMinho está prevista para dia 16 de setembro, no Multiuso de Guimarães. Pretende envolver antigos colegas da academia.
tags: Universidade do Minho, Multiusos de Guimarães, Alumni, Encontro Caixa Alumni UMinho 2023
type: article
---


# 8ª edição do Encontro dos Alumni UMinho prevista para 16 de setembro

## O evento terá lugar no Multiuso de Guimarães.

04Ago2023 | Margarida da Silva Carvalho

A 8ª edição do Encontro Caixa Alumni UMinho está prevista para dia 16 de setembro, no Multiuso de Guimarães. O evento começa a partir das 18h00 e tem como premissa promover o convívio entre antigos colegas que estudaram na Universidade do Minho.

O encontro é organizado pela academia minhota com o objetivo de “unir laços”. Segundo a nota de convite, “somos as mil asas que formam uma asa e, juntos, alcançamos o futuro”. Seguindo a tradição dos anos anteriores, depois do jantar segue-se um concerto com muita música e cor. As inscrições abrem em breve, a ser consultadas na página oficial do Facebook dos Alumni da Uminho.

