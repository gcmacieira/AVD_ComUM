---
date: 17Dez2021
author: Nuno Diogo Pereira
image: https://www.comumonline.com/wp-content/uploads/2017/01/IMG_0839-T55-1500x1000.jpg
title: UMinho é das primeiras universidades a ser abrangida pelo Plano de Recuperação e Resiliência
url: https://www.comumonline.com/2021/12/uminho-e-das-primeiras-universidades-a-ser-abrangida-pelo-plano-de-recuperacao-e-resiliencia/
site: ComUM
description: O acordo com a DGES já foi assinado e a UM vai ser uma das primeiras instituições de ensino a receber fundos provenientes do PRR.
tags: Universidade do Minho, Rui Vieira de Castro, Direção-Geral do Ensino Superior, Plano de Recuperação e Resiliência (PRR)
type: article
---


# UMinho é das primeiras universidades a ser abrangida pelo Plano de Recuperação e Resiliência

## A informação foi avançada por Rui Vieira de Castro durante a cerimónia dos 46 anos da Escola de Letras, Artes e Ciências Humanas (ELACH).

17Dez2021 | Nuno Diogo Pereira

O acordo com a Direção-Geral do Ensino Superior (DGES) já foi assinado e a Universidade do Minho (UMinho) vai ser uma das primeiras instituições de ensino a receber fundos provenientes do Plano de Recuperação e Resiliência (PRR). Segundo o reitor, Rui Vieira de Castro, a primeira transferência deverá ocorrer ainda no mês de dezembro.

A UMinho é uma das primeiras universidades portuguesas a fechar contrato com o governo, no âmbito da “bazuca europeia”. O responsável máximo da academia minhota avançou, em declarações à RUM, que “a expectativa é ter uma primeira transferência ainda este mês”, conseguida através da “aceleração que a universidade conseguiu introduzir neste processo”. Rui Vieira de Castro alertou ainda para a possibilidade de, daqui a dois anos, a instituição “concorrer a complementos de financiamento”.

Para já, os 13,5 milhões vão servir para “suportar a contratação de recursos humanos” e para fazer arrancar a “UMinho Education Alliance – Skills for a Better Future”, uma das 33 candidaturas aprovadas ao abrigo dos programas “Impulso Jovens STEAM” e “Impulso Adultos” da “bazuca europeia”. Quanto às bolsas de estudo, o reitor declarou que “vão existir”, não sendo ainda conhecido o número exato.

