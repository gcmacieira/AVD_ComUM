---
date: 16Dez2023
author: André Igreja
image: https://www.comumonline.com/wp-content/uploads/2023/12/marcelo-rebelo-de-sousa-1.jpeg
title: Presidente da República: “No quadro das novas universidades a UMinho conseguiu ir mais longe”
url: https://www.comumonline.com/2023/12/presidente-da-republica-no-quadro-das-novas-universidades-a-uminho-conseguiu-ir-mais-longe/
site: ComUM
description: O Presidente da República (PR), Marcelo Rebelo de Sousa, marcou presença no 30º aniversário da Escola de Direito da Universidade do Minho.
tags: UMinho, Escola de Direito, Presidente da República
type: article
---


# Presidente da República: “No quadro das novas universidades a UMinho conseguiu ir mais longe”

## No 30º aniversário da Escola de Direito, o Presidente da República aproveitou a cerimónia para homenagear Veiga Simão e Francisco Salgado Zenha.

16Dez2023 | André Igreja

O Presidente da República (PR), Marcelo Rebelo de Sousa, marcou presença no 30º aniversário da Escola de Direito da Universidade do Minho. Nas comemorações, o governante destacou a exceção que se vive na comunidade académica minhota: um caso de “juventude” num país “envelhecido”.

As primeiras palavras de Marcelo foram dirigidas para o reitor da UMinho, Rui Vieira de Castro, e para a presidente do Conselho Geral, Joana Marques Vidal. A dinâmica sentida na universidade contrasta com os “tropismos” próprios de uma sociedade crescentemente envelhecida. “Aqui sente-se o futuro da inovação mais do que o presente e o passado”, referiu o PR.

Na sua intervenção, houve também espaço para elogios ao legado de Veiga Simão, ministro da Educação Nacional entre 1970 e 1974, reformista e “fundador” da Universidade do Minho, assim como da Universidade Nova de Lisboa, da Universidade de Aveiro e o Instituto Universitário de Évora. O Presidente da República destacou a “visão nacional como internacional”, a sua aposta na “multidimensionalidade” e a atenção dada aos novos alunos que regressam à academia para atualizar conhecimentos.

O político e advogado bracarense Francisco Salgado Zenha, figura histórica da democracia, viu as comemorações do seu centenário de nascimento concluídas nesta cerimónia. Para Marcelo Rebelo de Sousa, foi “percursor” em dois campos – finanças e justiça – num período de queda de vários Governos Provisórios e instabilidade política, que hoje seria de insolvência do país.

 

 

 

 

