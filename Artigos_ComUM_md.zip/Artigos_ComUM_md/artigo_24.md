---
date: 09Mar2022
author: Maria Carvalho
image: https://www.comumonline.com/wp-content/uploads/2022/02/bandeira-ucrania-1-1060x663-1.jpeg
title: AEMinho disponibiliza 750 vagas de emprego para refugiados ucranianos
url: https://www.comumonline.com/2022/03/aeminho-disponibiliza-750-vagas-de-emprego-para-refugiados-ucranianos/
site: ComUM
description: A AEMinho angariou 750 vagas de trabalho para refugiados ucranianos. Cerca de 40 empresas responderam ao apelo da associação.
tags: Associação Empresarial do Minho (AEMinho), 750 vagas de trabalho para refugiados ucranianos, Ramiro Brito
type: article
---


# AEMinho disponibiliza 750 vagas de emprego para refugiados ucranianos

## O número de vagas foi alcançado em apenas uma semana.

09Mar2022 | Maria Carvalho

A Associação Empresarial do Minho (AEMinho) angariou 750 vagas de trabalho para refugiados ucranianos. Cerca de 40 empresas responderam ao apelo da associação, que tem um portal direcionado para o efeito. O maior número de vagas surge nas áreas da restauração e da hotelaria.

Em comunicado, o vice-presidente da AEMinho, Ramiro Brito, referiu que os empregos disponibilizados têm “uma abrangência significativa” e atravessam várias áreas, como construção civil, eletromecânica, indústria têxtil, tecnologias de informação ou arquitetura. “Ao contrário daquilo que costumava ser o padrão tradicional para este tipo de situações, temos ofertas abrangentes para quase todo os perfis que possam aparecer”, assegurou Ramiro Brito.

Depois de reunidas as vagas, o passo seguinte passa pela articulação com as entidades que estão a acompanhar a chegada dos cidadãos ucranianos, como as câmaras municipais, a Cruz Vermelha ou a Cáritas.

Para além da disponibilização de emprego e da entrega de bens por parte dos associados, a associação está a equacionar alargar a resposta, direcionada para bebés e crianças. Nesse sentido, a ideia é desenvolver um projeto, em parceria com os estabelecimentos de ensino com cursos nas áreas da educação e da ação social e com as autarquias, criando espaços e destinando recursos humanos para tomar conta dos filhos dos trabalhadores.

Ramiro Brito esclareceu que vão continuar a ser estabelecidas “iniciativas concretas para dar resposta às necessidades humanitárias que resultam desta invasão” e apelou ao isolamento da Rússia “em termos económicos e empresariais”.

