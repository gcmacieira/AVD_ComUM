---
date: 30Mai2019
author: Catarina Ferreira
image: https://www.comumonline.com/wp-content/uploads/2019/05/ea0bc75e57985eee9ba9a1b660f72680_w1000.jpg
title: AAUM de prata no nacional universitário de Kickboxing
url: https://www.comumonline.com/2019/05/aaum-de-prata-no-nacional-universitario-de-kickboxing/
site: ComUM
description: A Associação Académica da Universidade do Minho (AAUM) ficou no segundo lugar do pódio atrás da Universidade do Porto (UPorto) e à frente da Associação
tags: AAUM, Kickboxing, Campeonato Nacional Universitário
type: article
---


# AAUM de prata no nacional universitário de Kickboxing

## Cinco medalhas a título individual para os atletas da UMinho. Rita Novais e Sofia Oliveira foram as estudantes premiadas com o ouro.

30Mai2019 | Catarina Ferreira

A Associação Académica da Universidade do Minho (AAUM) ficou no segundo lugar do pódio atrás da Universidade do Porto (UPorto) e à frente da Associação Académica da Universidade de Évora (AAUE) no Campeonato Nacional Universitário de Kickboxing Lowkick. Na prova que decorreu a 26 de maio na Covilhã, os atletas conquistaram ainda, individualmente, duas medalhas de ouro, uma de prata e das de bronze.

Em feminino, na categoria <56kg, Rita Novais, aluna de mestrado em Sistemas de Informação, ficou em primeiro lugar, seguida de Francisca Cardoso do Instituto Politécnico de Santarém.  Na categoria <65kg, o ouro também foi para uma atleta da academia minhota. Sofia Oliveira, aluna de Mestrado Integrado em Engenharia Eletrónica Industrial e Computadores, fez o pleno de vitórias em três de participação. Diana Fonseca da Associação de Estudantes da Faculdade de Ciências de Lisboa ocupou o segundo posto.

Já no masculino, João Marques e José Guerrinha da AAUE ficaram no primeiro e segundo lugares, respetivamente, na categoria <57kg. Em <63,5 Pedro Ferreira, da Academia da Força Aérea (AFA), João Dias, da Associação de Estudantes Instituto Superior de Contabilidade e Administração de Coimbra e Áureo Benedito, aluno de Ciências da Computação da AAUM ocuparam, por esta ordem, o pódio.

Na categoria <67kg, ficou em primeiro o atleta da UPorto, João Barbosa, seguido de Paulo Silva, da Associação Académica de Coimbra (AAC), e com a medalha de prata ficou o estudante de Mestrado Integrado em Engenharia Informática da AAUM, Luís Gomes. João Freitas, da UPorto, ficou no lugar mais alto do pódio, em <71kg. Atrás dele, Luiz Alexandre, aluno de Engenharia Eletrónica na academia minhota, ocupou o segundo posto e Gonçalo Brito, da AAC, o terceiro.

No pódio das categorias <75kg, <81kg e >91kg não ficou nenhum atleta da AAUM. Na primeira foi Tomás Nazareh, da UPorto o grande vencedor. Na segunda, José Valério da AFA conquistou o ouro. E na última categoria, Diogo Castro, da UPorto, conseguiu subir ao lugar mais alto do pódio.

Apesar dos atletas da AAUM terem conquistado cinco medalhas, o total de pontos não foi suficiente para triunfar a nível coletivo, ficando em segundo lugar atrás da UPorto. No final, Manuel Gomes, responsável pela modalidade na Universidade do Minho, fez um balanço da competição. “Foi uma boa prova, tendo em conta o nível de experiência dos nossos atletas. O nível da competição foi bom, apesar do desequilíbrio, pois, tivemos atletas profissionais a combater com iniciantes”, comentou.

 

 

