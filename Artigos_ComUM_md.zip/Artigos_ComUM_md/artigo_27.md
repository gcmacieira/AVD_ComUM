---
date: 
author: 
image: 
title: Aluno da UMinho eleito presidente da Academia Europeia de Optometria e Ótica
url: https://www.comumonline.com/2015/04/aluno-da-uminho-eleito-presidente-da-academia-europeia-de-optometria-e-otica/
site: ComUM
description: 
tags: Universidade do Minho, Academia Europeia de Optometria e Ótica
type: article
---


# Aluno da UMinho eleito presidente da Academia Europeia de Optometria e Ótica

## 

 | 

Eduardo Teixeira, mestrando em Optometria Avançada na Universidade do Minho, foi eleito presidente da Academia Europeia de Optometria e Ótica (EAOO, na sigla em inglês). O estudante é o primeiro português a presidir a associação.

O aluno de mestrado da UMinho inicia o seu mandato em maio de 2017. Por enquanto, Eduardo Teixeira, de 38 anos, vai tomar posse como vice-presidente da entidade que tem sede em Londres e agrega mais de 600 cientistas de instituições da Europa e de países como EUA, Irão e Israel.

O aluno de Optometria Avançada confessa que esta oportunidade o deixa “muito feliz, mas consciente de que há muito trabalho para fazer”.  “Queremos melhorar os standards e homogeneizar a prática e o conhecimento desta ciência”, acrescenta.

Eduardo Teixeira acredita que, embora se trate de um organismo jovem, a EAOO tem um grande potencial de crescimento. “Vamos procurar envolver cada vez mais universidades e centros científicos, nomeadamente em Portugal”, afirma.

A Academia Europeia de Optometria e Ótica, que existe desde 2009, tem como objetivo afirmar o setor da optometria e da ótica na sociedade e unir os cientistas, os profissionais e a indústria.

