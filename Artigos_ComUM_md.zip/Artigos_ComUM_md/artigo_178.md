---
date: 03Out2023
author: André Igreja
image: https://www.comumonline.com/wp-content/uploads/2022/10/Jose-Costa_Universidade-do-Minho_08-1500x1000.jpg
title: UMinho debate ensino superior e direitos humanos na Ucrânia
url: https://www.comumonline.com/2023/10/uminho-debate-ensino-superior-e-direitos-humanos-na-ucrania/
site: ComUM
description: A Universidade do Minho vai promover dois debates, entre hoje e amanhã, sobre o ensino superior e os direitos humanos no conflito entre Ucrânia e Rússia.
tags: ensino superior, UMinho, Direitos Humanos, Guerra entre Rússia e Ucrânia
type: article
---


# UMinho debate ensino superior e direitos humanos na Ucrânia

## Académica ucraniana Myroslava Antonovych vai protagonizar os dois debates.

03Out2023 | André Igreja

A Universidade do Minho vai promover discussões, esta semana, sobre o ensino superior e os direitos humanos no conflito entre Ucrânia e Rússia. O primeiro dos dois debates realiza-se esta tarde, na Biblioteca Pública de Braga, com a participação da ucraniana Myroslava Antonovych, diretora do Centro de Estudos em Genocídio e Direitos Humanos da Universidade Nacional de Kiev-Mohyla.

De acordo com uma nota enviada pela UMinho, a oradora “vai analisar o papel das instituições académicas na preparação de cidadãos mais conscientes do valor social dos direitos humanos, entre outros aspetos”. Manuel João Costa, pró-reitor para os Assuntos Estudantis e Inovação Pedagógica da Universidade do Minho, ficará encarregue da moderação.

Amanhã, quarta-feira, a responsável ucraniana vai trazer à Escola de Direito da Universidade do Minho (EDUM), no campus de Gualtar, uma apresentação sobre o rapto e a transferência de crianças do país invadido pela Rússia. A sessão terá início às 15h00, com a moderação de Patrícia Jerónimo e os comentários de Assunção do Vale Pereira, ambas professoras da EDUM.

Os debates vão ser realizados no âmbito da rede Arqus, uma aliança multilateral e internacional de várias instituições de ensino superior que partilham a mesma visão educativa e objetivos académicos e culturais. Destaca-se que, em setembro, uma dezena de estudantes universitários da Ucrânia estiveram uma semana na UMinho a conhecer vários projetos e valências da academia.

