---
date: 10Jul2017
author: Carina Teixeira
image: https://www.comumonline.com/wp-content/uploads/2016/01/20140430630773153750-1500x994.jpg
title: UMinho não aumenta valor da propina no próximo ano letivo
url: https://www.comumonline.com/2017/07/uminho-nao-aumenta-valor-da-propina-no-proximo-ano-letivo/
site: ComUM
description: 
tags: Universidade do Minho, UMinho, propina
type: article
---


# UMinho não aumenta valor da propina no próximo ano letivo

## 

10Jul2017 | Carina Teixeira

A Universidade do Minho não vai aumentar o valor das propinas do 1.º ciclo e mestrado integrado para o ano letivo de 2017/2018. Este é já o quinto ano consecutivo em que não há alteração do valor da propina, ficando nos 1037,20€.

A proposta apresentada pelo reitor da UMinho, em Conselho Geral, foi aprovada com um voto contra por parte dos 4 estudantes representantes do órgão e estende-se também às propinas do 2.º e 3.º ciclos de ensino.

Atualmente, o valor máximo de propina em Portugal é de 1063€ e o mínimo 689€. Apesar de a UMinho não praticar o valor máximo, a Associação Académica da Universidade do Minho defende que o valor atual é “demasiado elevado face à realidade socioeconómica, verificando-se que Portugal é um dos países da OCDE que pratica valores de propina mais elevados”. A associação diz ainda que cabe ao Governo reforçar o financiamento das instituições do ensino superior para garantir a qualidade do ensino.

