---
date: 25Nov2023
author: Ana Beatriz Ferreira
image: https://www.comumonline.com/wp-content/uploads/2023/11/IMG_6758-1500x1000.jpg
title: Reivindicação estudantil: “É preciso investir, queremos camas para dormir” [fotogaleria]
url: https://www.comumonline.com/2023/11/reivindicacao-estudantil-e-preciso-investir-queremos-camas-para-dormir/
site: ComUM
description: Esta quarta-feira o Largo do Paço encheu-se de gritos e reivindicações estudantis. Um grupo de alunos minhotos organizou o movimento para apelar à reitoria e a outros órgãos administrativos por melhores condições nas residências universitárias. As queixas passaram ainda pelo atraso da bolsa e pelos preços dos alojamentos.
tags: ComUM, Multimédia, Residências Universitárias
type: article
---


# Reivindicação estudantil: “É preciso investir, queremos camas para dormir” [fotogaleria]

## 

25Nov2023 | Ana Beatriz Ferreira

Esta quarta-feira o Largo do Paço encheu-se de gritos e reivindicações estudantis. Um grupo de alunos minhotos organizou o movimento para apelar à reitoria e a outros órgãos administrativos por melhores condições nas residências universitárias. As queixas passaram ainda pelo atraso da bolsa e pelos preços dos alojamentos.

