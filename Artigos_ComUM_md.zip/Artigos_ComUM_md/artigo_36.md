---
date: 20Set2023
author: Marta Rodrigues
image: https://www.comumonline.com/wp-content/uploads/2023/09/ArraialAzeiteiro_MartaRodrigues13-1500x1000.jpg
title: Arraial Azeiteiro. O ano arranca com animação da Azeituna [fotogaleria]
url: https://www.comumonline.com/2023/09/arraial-azeiteiro-o-ano-arranca-com-animacao-da-azeituna/
site: ComUM
description: Realizou-se esta terça-feira, dia 19 de setembro, o Arraial Azeiteiro, uma festa organizada pela Azeituna - Tuna de Ciências da Universidade do Minho.
tags: Azeituna, UMinho, Braga, Arraial Azeiteiro
type: article
---


# Arraial Azeiteiro. O ano arranca com animação da Azeituna [fotogaleria]

## 

20Set2023 | Marta Rodrigues

Realizou-se esta terça-feira, dia 19 de setembro, o Arraial Azeiteiro, uma festa organizada pela Azeituna – Tuna de Ciências da Universidade do Minho. O campo de jogos de Gualtar encheu-se de centenas de estudantes, que se reuniram para celebrar o início de mais um ano letivo.

Da programação fez parte a atuação da tuna organizadora, assim como do cantor Nel Monteiro, os Tinder Bueno e o DJ Set Miguel e João. Vários cursos também marcaram presença nas habituais barraquinhas. Música, animação e gargalhadas não faltaram nesta noite.

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

Marta Rodrigues | ComUM

