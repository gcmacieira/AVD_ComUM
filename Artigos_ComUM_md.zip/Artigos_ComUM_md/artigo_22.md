---
date: 22Abr2023
author: Carina Ribeiro
image: https://www.comumonline.com/wp-content/uploads/2023/04/d339691a5f69abb73b21c83ffc840d93_w840.png
title: AAUMinho vence as primeiras finais do Campeonato Nacional Universitário
url: https://www.comumonline.com/2023/04/aauminho-vence-as-primeiras-finais-do-campeonato-nacional-universitario/
site: ComUM
description: Durante esta semana e a próxima, decorrem os Campeonatos Nacionais Universitários. Nesta primeira semana de competição a AAUMinho já ganhou quatro títulos.
tags: Viana do Castelo, Campeonatos Nacionais Universitários, Voleibol Feminino, AAUMinho, Andebol Feminino, Campeonatos Nacionais Universitários 2023, Futsal Masculino, Basquetebol Masculino
type: article
---


# AAUMinho vence as primeiras finais do Campeonato Nacional Universitário

## A AUMinho foi a única academia que esteve em todas as finais e conseguiu sorrir em todas.

22Abr2023 | Carina Ribeiro

Durante esta semana e a próxima, decorrem em Viana do Castelo as fases finais dos Campeonatos Nacionais Universitários de 2023. Nesta primeira semana de competição organizada pela Federação Académica do Desporto Universitário (FADU), estiveram em ação as equipas de andebol feminino, futsal masculino, basquetebol masculino e voleibol feminino.

As equipas de estudantes da Academia Minhota conseguiram chegar ao ouro nas respetivas competições. A primeira turma a sagrar-se campeã nacional, foi a de andebol feminino, que disputou a final no Pavilhão José Natário. As estudantes-atletas venceram a derradeira partida por 33-29, frente à Universidade do Porto.

O percurso das minhotas foi imaculado desde que chegaram a Viana do Castelo. Na fase de grupos que decorreu no início da semana, a AAUMinho venceu os dois jogos que disputou. Primeiro superou as portuenses do AEISCAP por 23-15 e no dia seguinte venceu as estudantes da Universidade de Lisboa por 25-13. Já na meia final venceu de forma tranquila a AAUAv por 40-25.

Nesta sexta-feira, a AAUMinho alargou o seu palmarés com mais três títulos nacionais. No período da manhã a equipa de voleibol feminino, também no Pavilhão José Natário, o reduto das finais, as minhotas chegaram ao lugar mais alto do pódio depois de vencerem o AEICBAS, por 3-0.

Até chegar às finais o emblema da Academia Minhota, não cedeu nenhuma derrota. Primeiro venceram as suas adversárias da final, por 2-1. Depois superaram as alunas da AEFML por 2-0. E garantiram o acesso às meias finais com mais uma vitória frente ao AEFMUP, por 2-1. Nas meias finais superaram a AEPort por 3-1.

Ao início da tarde foi a vez da equipa de basquetebol masculino, liderada por Alexandre Oliveira, entrar em ação. Mesmo depois de ter estado com uma desvantagem de nove pontos, os minhotos conseguiram equilibrar a partida e levar a melhor por 79-73.

A equipa masculina de basquetebol da AAUMinho iniciou o seu percurso mais cedo, depois de ter disputado no domingo o playoff de acesso à fase final. Nessa partida, defrontaram a AAUA e venceram por 53-31. Na fase de grupos não entraram da melhor maneira, uma vez que foram derrotados pela AEFCT, por 52-59. Contudo nas outras duas partidas levaram a melhor frente à AEFADEUP (65-41) e à AAC (65-49). Na meia final conseguiram levar a melhor de forma clara ao derrotarem a AEFEUP por 73-57.

Por fim, à noite foi a turma de futsal que trouxe o quarto e último título que foi disputado durante esta semana. Os minhotos encontraram na final os atletas do Instituto Politécnico de Coimbra, que mesmo depois de utilizarem o esquema tático de guarda redes avançado, não conseguiram levar a melhor. Os minhotos acabaram por vencer por 3-2.

A AAUMinho entrou da melhor maneira na fase de grupos ao golear a AEFADEUP por 9-2. Não pôs o pé no travão e voltou a golear no segundo encontro, desta vez frente à AEISCTE, com oito golos sem resposta. Na última partida desta fase teve um encontro mais equilibrado frente ao IPVC, mas mesmo assim venceu por 4-2. Nas meias finais defrontaram a AEUMAIA e voltaram a vencer por 4-1.

Na próxima semana entram em ação mais quatro equipas da Associação Académica da Universidade do Minho, que pretendem alcançar mais quatro títulos. Desta vez as equipas que entram em ação são as de futsal feminino, basquetebol feminino, andebol masculino e voleibol masculino.

