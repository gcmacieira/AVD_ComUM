---
date: 19Set2022
author: Carina Ribeiro
image: https://www.comumonline.com/wp-content/uploads/2019/09/acolhimento_joanabraganca05-1500x1000.jpg
title: Reitor recebe os novos alunos na cerimónia de boas-vindas
url: https://www.comumonline.com/2022/09/reitor-recebe-os-novos-alunos-na-cerimonia-de-boas-vindas/
site: ComUM
description: Durante esta segunda-feira, cerca de 2.900 novos alunos da Universidade do Minho (UMinho) foram recebidos pelo reitor Rui Vieira de Castro.
tags: Universidade do Minho, UMinho, Acolhimento, Reitor Rui Vieira de Castro, AAUMinho, Duarte Lopes
type: article
---


# Reitor recebe os novos alunos na cerimónia de boas-vindas

## O membro máximo da Academia Minhota discursou no primeiro dia de aulas.

19Set2022 | Carina Ribeiro

Durante esta segunda-feira, cerca de 2.900 novos alunos da Universidade do Minho (UMinho) foram recebidos pelo reitor Rui Vieira de Castro. A cerimónia teve início às 15h30 e decorreu no Pavilhão Desportivo do campus de Gualtar, em Braga.

Ao longo da sessão, para além das palavras do reitor, também o presidente da Associação Académica da Universidade do Minho (AAUMinho), Duarte Lopes, discursou para os caloiros. Para um melhor acolhimento aos novos estudantes, esta sessão contou com testemunhos de ex-alunos, vídeos e atuações de alguns grupos culturais da Academia Minhota: o Coro Académico da UMinho (CAUM), a Tuna Universitária do Minho (TUM) e os Bomboémia. Para além disso, o evento foi transmitido em direto no Youtube e Facebook da UMinho e na Rádio Universitária do Minho (RUM).

A iniciativa pertence ao plano de Acolhimento que a reitoria promoveu, juntamente com a AAUM e Unidades Orgânicas e Serviços. Os alunos tiveram direito ao almoço gratuito, oferecido pela reitoria e também dispensa das aulas no período da tarde.

Nos próximos dias o programa de Acolhimento segue o plano estabelecido e os caloiros têm ao seu dispor várias atividades. A próxima ocorre já esta terça-feira, consistindo numa mostra associativa nos campi e o plano encerra com os concertos noturnos no Pavilhão Multiusos de Guimarães. Ainda, a AAUMinho também está a promover ações de saúde mental.

