---
date: 13Abr2021
author: Débora Monteiro
image: https://www.comumonline.com/wp-content/uploads/2021/04/AAUMinho-por-21-banner-cartaz-geral-1.png
title: AAUMinho reintegra Dias Sociais +Por+
url: https://www.comumonline.com/2021/04/aauminho-reintegra-dias-sociais-por/
site: ComUM
description: A edição de 2021 dos dias sociais +Por+ realiza-se novamente entre os dias 12 e 14 abril, via online, organizada pela AAUMinho.
tags: Universidade do Minho, AAUM, Voluntariado, +Por+, Dias Sociais
type: article
---


# AAUMinho reintegra Dias Sociais +Por+

## A edição de 2021 realiza-se entre os dias 12 e 14 abril, via online.

13Abr2021 | Débora Monteiro

Os Dias Sociais +Por+ proporcionados pela Associação Académica da Universidade do Minho iniciaram-se dia 12 de abril, em formato digital. O intuito do evento passa por aproximar os estudantes a algumas questões atuais, tais como o bem-estar, a pandemia e o voluntariado.

A sessão começou com o tópico “+Bem-estar” onde se disponibilizou uma Masterclass sobre a Gestão do Stress e uma conversa acerca de “Como lidar?” com a Síndrome de Burnout. “Como a Pandemia mudou as Relações Humanas?” é o tema central do segundo dia do evento e, no último dia, a AAUMinho focar-se-á na solidariedade, em particular em questões como “E agora, como faço voluntariado internacional?”.

A iniciativa concebida pela AAUMinho consiste em garantir um momento de interação, reflexão e aprendizagem sobre as diversas temáticas que, atualmente, mantém os jovens em constante debate. Ao longo dos três Dias Sociais, ocorrem várias palestras que pretendem amplificar o conhecimento destes temas aos estudantes do Minho.

