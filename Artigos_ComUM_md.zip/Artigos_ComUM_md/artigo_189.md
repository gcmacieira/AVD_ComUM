---
date: 
author: 
image: 
title: UMinho integra o ranking mundial das 400 melhores universidades
url: https://www.comumonline.com/2013/10/uminho-integra-o-ranking-mundial-das-400-melhores-universidades/
site: ComUM
description: 
tags: Universidade do Minho
type: article
---


# UMinho integra o ranking mundial das 400 melhores universidades

## 

 | 

A Universidade do Minho (UMinho) e a Universidade do Porto (UP) são as únicas universidades portuguesas que integram o ranking das 400 melhores universidades do mundo, segundo a Times Higher Education (THE).

Renata Jorge, aluno do 1º ano de Direito na UMinho, disse ao ComUM que este reconhecimento deve-se “ao índice de empregabilidade dos cursos”.

“O alto nível de exigência [da UMinho] em relação a outras universidades e o facto de os professores serem reconhecidos a nível internacional” são os motivos apontados por Marcos Pereira, estudante do 3º ano do mestrado integrado em Engenharia Eletrónica Industrial e Computadores para a permanência da UMinho noranking da THE.

Em 2011, o ranking elaborado pela THE colocava quatro universidades portuguesas entre as 400 melhores do mundo, entre elas a Universidade de Aveiro, do Porto, de Coimbra e a Nova de Lisboa. Já a UMinho passou a figurar na lista no ano de 2012.

O THE sustenta o seu ranking em 13 critérios de avaliação, continuando a ser liderado pelas universidades norte-americanas e registando um aumento significativo de universidades asiáticas no top 400.

Ana Daniela Pereira
Daniela Soares

