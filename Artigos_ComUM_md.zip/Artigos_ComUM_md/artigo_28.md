---
date: 05Mar2016
author: Hélio Carvalho
image: https://www.comumonline.com/wp-content/uploads/2016/01/20140430630773153750-1500x994.jpg
title: Alunos da UMinho juntos com Hospital de Braga em voluntariado
url: https://www.comumonline.com/2016/03/alunos-da-uminho-e-hospital-de-braga-juntos-em-voluntariado/
site: ComUM
description: 
tags: UMinho, 2016, Hospital de Braga
type: article
---


# Alunos da UMinho juntos com Hospital de Braga em voluntariado

## A Universidade do Minho e o Hospital de Braga vão dar as mãos num programa de voluntariado que se irá desenvolver ao longo de todo o ano. O protocolo, assinado no início do mês de janeiro, pretende que haja um crescimento do número de estudantes a voluntariarem-se no hospital, aumentando assim a cooperação entre as duas entidades.

05Mar2016 | Hélio Carvalho

Na cerimónia que celebrou o acordo entre a universidade e o centro hospitalar, João Ferreira, presidente da comissão executiva do Hospital de Braga, assumiu, em declarações ao site do Hospital, que este acordo permitirá melhorar a qualidade dos serviços, enquanto Carlos Videira, que entretanto terminou o seu mandato como presidente da AAUM, decidiu “agradecer à reitoria” a possibilidade de realizar este protocolo.

Marta Campos, directora do Departamento Social da associação académica, sublinhou a importância que este acordo poderá ter na formação dos estudantes. “É um acordo em que o Hospital disponibiliza uma formação em voluntariado a todos os estudantes que sejam aceites no programa”, disse ao nosso jornal, destacando ainda o facto de o serviço fornecer uma instrução em suporte básico de vida.

Ainda em declarações ao ComUM, Marta Campos esclareceu que o papel da AAUM será de “informar todos os alunos sobre o programa, e promover acções de divulgação sobre o voluntariado no hospital”. Disse ainda que não há um número esperado de candidatos ao programa, mas que foi estabelecido que de todos os candidatos, 100 alunos serão escolhidos pela AAUM na primeira entrevista, sendo que caberá ao hospital escolher os 50 melhores candidatos.

As inscrições para o programa estão abertas desde quinta-feira, dia 3, e prolongam-se até dia 9 de Março. A escolha dos candidatos será dividida em duas entrevistas, e o formulário para a inscrição está disponível no Gabinete de Apoio ao Aluno dos campi de Gualtar e Azurém.

